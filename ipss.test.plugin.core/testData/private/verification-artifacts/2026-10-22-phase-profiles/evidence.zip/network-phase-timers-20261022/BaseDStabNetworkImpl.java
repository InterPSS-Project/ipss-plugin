/**
 * <copyright>
 * </copyright>
 *
 * $Id: DStabilityNetworkImpl.java,v 1.21 2007/07/18 23:19:07 mzhou Exp $
 */
package com.interpss.dstab.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.math3.complex.Complex;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.interpss.numeric.datatype.Complex3x1;
import org.interpss.numeric.exp.IpssNumericException;
import org.interpss.numeric.sparse.ISparseEqnComplex;
import org.interpss.numeric.util.Number2String;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.interpss.common.datatype.Constants;
import com.interpss.common.exp.InterpssException;
import com.interpss.common.exp.InterpssRuntimeException;
import com.interpss.dstab.common.IDStabNetChangeListener;
import com.interpss.core.aclf.AclfGen;
import com.interpss.core.aclf.AclfGenCode;
import com.interpss.core.aclf.AclfLoadCode;
import com.interpss.core.acsc.SequenceCode;
import com.interpss.core.acsc.impl.BaseAcscNetworkImpl;
import com.interpss.core.algo.sc.ScBusModelType;
import com.interpss.core.net.Bus;
import com.interpss.core.net.DataCheckConfiguration;
import com.interpss.dstab.BaseDStabBus;
import com.interpss.dstab.BaseDStabNetwork;
import com.interpss.dstab.DStabBranch;
import com.interpss.dstab.DStabGen;
import com.interpss.dstab.DStabLoad;
import com.interpss.dstab.DStabObjectFactory;
import com.interpss.dstab.DstabPackage;
import com.interpss.dstab.StaticLoadModel;
import com.interpss.dstab.devent.DynamicSimuEvent;
import com.interpss.dstab.devent.DynamicSimuEventType;
import com.interpss.dstab.devent.SetPointChangeEvent;
import com.interpss.dstab.device.DynamicBusDevice;
import com.interpss.dstab.device.DynamicBusDeviceType;
import com.interpss.dstab.device.DynamicDevice;
import com.interpss.dstab.device.ScriptDynamicBusDevice;
import com.interpss.dstab.dynLoad.DynLoadModel;
import com.interpss.dstab.mach.Machine;
import com.interpss.dstab.relay.IRelayModel;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>DStability Network</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#isDStabNetInitialized <em>DStab Net Initialized</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#isAllowGenWithoutMach <em>Allow Gen Without Mach</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#getYMatrix <em>YMatrix</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#getZeroSeqYMatrix <em>Zero Seq YMatrix</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#getNegSeqYMatrix <em>Neg Seq YMatrix</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#isYMatrixDirty <em>YMatrix Dirty</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#getStaticLoadModel <em>Static Load Model</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#getStaticLoadSwitchVolt <em>Static Load Switch Volt</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#getStaticLoadSwitchDeadZone <em>Static Load Switch Dead Zone</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#getNetEqnIterationNoEvent <em>Net Eqn Iteration No Event</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#getNetEqnIterationWithEvent <em>Net Eqn Iteration With Event</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#isSaturatedMachineParameter <em>Saturated Machine Parameter</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#getNetChangeListener <em>Net Change Listener</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#getDynamicEventList <em>Dynamic Event List</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#getRelayModelList <em>Relay Model List</em>}</li>
 *   <li>{@link com.interpss.dstab.impl.BaseDStabNetworkImpl#getGenWithoutBusList <em>Gen Without Bus List</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BaseDStabNetworkImpl<TBus extends BaseDStabBus<? extends DStabGen, ? extends DStabLoad>, TBra extends DStabBranch> extends BaseAcscNetworkImpl<TBus, TBra> implements BaseDStabNetwork<TBus, TBra> {
    private static final Logger log = LoggerFactory.getLogger(BaseDStabNetworkImpl.class);
	
	
	
	/**
	 * The default value of the '{@link #isDStabNetInitialized() <em>DStab Net Initialized</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isDStabNetInitialized()
	 * @generated
	 * @ordered
	 */
	protected static final boolean DSTAB_NET_INITIALIZED_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isDStabNetInitialized() <em>DStab Net Initialized</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isDStabNetInitialized()
	 * @generated
	 * @ordered
	 */
	protected boolean dStabNetInitialized = DSTAB_NET_INITIALIZED_EDEFAULT;

	/**
	 * The default value of the '{@link #isAllowGenWithoutMach() <em>Allow Gen Without Mach</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isAllowGenWithoutMach()
	 * @generated
	 * @ordered
	 */
	protected static final boolean ALLOW_GEN_WITHOUT_MACH_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isAllowGenWithoutMach() <em>Allow Gen Without Mach</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isAllowGenWithoutMach()
	 * @generated
	 * @ordered
	 */
	protected boolean allowGenWithoutMach = ALLOW_GEN_WITHOUT_MACH_EDEFAULT;

	/**
	 * The default value of the '{@link #getYMatrix() <em>YMatrix</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getYMatrix()
	 * @generated
	 * @ordered
	 */
	protected static final ISparseEqnComplex YMATRIX_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getYMatrix() <em>YMatrix</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getYMatrix()
	 * @generated
	 * @ordered
	 */
	protected ISparseEqnComplex yMatrix = YMATRIX_EDEFAULT;

	/**
	 * The default value of the '{@link #getZeroSeqYMatrix() <em>Zero Seq YMatrix</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getZeroSeqYMatrix()
	 * @generated
	 * @ordered
	 */
	protected static final ISparseEqnComplex ZERO_SEQ_YMATRIX_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getZeroSeqYMatrix() <em>Zero Seq YMatrix</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getZeroSeqYMatrix()
	 * @generated
	 * @ordered
	 */
	protected ISparseEqnComplex zeroSeqYMatrix = ZERO_SEQ_YMATRIX_EDEFAULT;

	/**
	 * The default value of the '{@link #getNegSeqYMatrix() <em>Neg Seq YMatrix</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNegSeqYMatrix()
	 * @generated
	 * @ordered
	 */
	protected static final ISparseEqnComplex NEG_SEQ_YMATRIX_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNegSeqYMatrix() <em>Neg Seq YMatrix</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNegSeqYMatrix()
	 * @generated
	 * @ordered
	 */
	protected ISparseEqnComplex negSeqYMatrix = NEG_SEQ_YMATRIX_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	protected Hashtable<String, Complex> customBusCurTable =null;
	
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	protected Hashtable<String, Complex3x1> custom3SeqBusCurTable =null;
	
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	protected boolean genWithoutMachAllowed = false;
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	protected boolean hasGenWithoutMach = false;
    private final List<DStabGen> generatorsWithoutDynamicModels = new ArrayList<>();
    private boolean dynamicModelInventoryValid;
    private boolean collectingDynamicModelInventory;
    private long dynamicModelInventoryBuildCount;

    /** Number of full-check or fallback inventory passes, for diagnostics. */
    public long getDynamicModelInventoryBuildCount() { return dynamicModelInventoryBuildCount; }

    private transient BaseDStabBus<?,?>[] dynamicRuntimeBusArray;
    private BaseDStabBus<?,?>[] dynamicRuntimeBuses() {
        if (getClass()!=com.interpss.dstab.impl.DStabilityNetworkImpl.class)
            return getBusList().toArray(BaseDStabBus<?,?>[]::new);
        if (dynamicRuntimeBusArray == null)
            dynamicRuntimeBusArray=getBusList().toArray(BaseDStabBus<?,?>[]::new);
        return dynamicRuntimeBusArray;
    }
    private long runtimeMembershipVersion;
    public long getRuntimeMembershipVersion() {return runtimeMembershipVersion;}
    @Override public EList<TBra> getBranchList() {
        if(branchList==null)branchList=new org.eclipse.emf.ecore.util.EObjectEList<TBra>(
                com.interpss.core.net.Branch.class,this,com.interpss.core.net.NetPackage.NETWORK__BRANCH_LIST) {
            @Override protected void didChange() {super.didChange();invalidateDStabModelInventory();}
        };
        return branchList;
    }
    @Override public void invalidateDStabModelInventory() {
        runtimeMembershipVersion++;
        dynamicModelInventoryValid = false; dynamicRuntimeBusArray=null;
    }

    @Override public EList<TBus> getBusList() {
        if (busList == null) {
            busList = new org.eclipse.emf.ecore.util.EObjectEList<TBus>(Bus.class, this,
                    com.interpss.core.net.NetPackage.NETWORK__BUS_LIST) {
                @Override protected void didChange() {
                    super.didChange();
                    invalidateDStabModelInventory();
                }
            };
        }
        return busList;
    }

	//TODO
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	
	protected List<BaseDStabBus<DStabGen,DStabLoad>> genWithoutMachBusList = new ArrayList<>();
	
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	protected boolean isInitialized = false;
	
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	protected boolean isStaticLoadIncludedInYMatrix = true;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BaseDStabNetworkImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	@Override
	public boolean checkData(DataCheckConfiguration config) {
        if (config.isAllowGenWithoutMachine()) setAllowGenWithoutMach(true);
        beginDynamicModelInventory();
        boolean pass;
        try {
            // Bus checks collect the pending units during the existing pass.
            pass = super.checkData(config);
            // Programmatic/ACSC networks may attach models after power flow.
            // Preserve their existing validation scope, but collect the inventory
            // in this one pass so preparation can reject or net missing units.
            if (!isLfDataLoaded()) for (BaseDStabBus<?, ?> bus : getBusList()) {
                if (isAllowGenWithoutMach()) {
                    boolean valid = bus instanceof BaseDStabBusImpl<?, ?> impl
                            ? impl.checkDynamicGeneratorData(config) : bus.checkData(config);
                    if (!valid) pass = false;
                } else if (bus.isActive()) {
                    for (DStabGen gen : bus.getContributeGenList()) {
                        if (gen.isActive() && gen.getDynamicGenDevice() == null)
                            recordGeneratorWithoutDynamicModel(gen);
                        else if (!gen.isActive() && gen.getDynamicGenDevice() != null)
                            gen.getDynamicGenDevice().setStatus(false);
                    }
                }
            }
            dynamicModelInventoryValid = true;
        } finally {
            collectingDynamicModelInventory = false;
        }
        for (DynamicSimuEvent event : getDynamicEventList())
            if (!event.checkData(config)) pass = false;
        // Checking inventories the missing devices without changing the power-flow
        // problem. Net their final solved P/Q in prepareDStabModels().
        if (isLfDataLoaded() && hasGenWithoutMach && !isAllowGenWithoutMach()) pass = false;

		if(getStaticLoadModel() == StaticLoadModel.CONST_P && getStaticLoadSwitchVolt() < 0.5) {
			log.error("Static load switching voltage < 0.5pu");
			pass = false;
		} 
		
		return pass;
	}
	
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DstabPackage.Literals.BASE_DSTAB_NETWORK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setYMatrix(ISparseEqnComplex newYMatrix) {
		ISparseEqnComplex oldYMatrix = yMatrix;
		yMatrix = newYMatrix;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DstabPackage.BASE_DSTAB_NETWORK__YMATRIX, oldYMatrix, yMatrix));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ISparseEqnComplex getZeroSeqYMatrix() {
		if(zeroSeqYMatrix==null)
			zeroSeqYMatrix =this.formScYMatrix(SequenceCode.ZERO, ScBusModelType.LOADFLOW_VOLT, true);
	
		return zeroSeqYMatrix;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setZeroSeqYMatrix(ISparseEqnComplex newZeroSeqYMatrix) {
		ISparseEqnComplex oldZeroSeqYMatrix = zeroSeqYMatrix;
		zeroSeqYMatrix = newZeroSeqYMatrix;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DstabPackage.BASE_DSTAB_NETWORK__ZERO_SEQ_YMATRIX, oldZeroSeqYMatrix, zeroSeqYMatrix));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ISparseEqnComplex getNegSeqYMatrix() {
		if(negSeqYMatrix==null)
			negSeqYMatrix =this.formScYMatrix(SequenceCode.NEGATIVE, ScBusModelType.LOADFLOW_VOLT, true);
	
		return negSeqYMatrix;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setNegSeqYMatrix(ISparseEqnComplex newNegSeqYMatrix) {
		ISparseEqnComplex oldNegSeqYMatrix = negSeqYMatrix;
		negSeqYMatrix = newNegSeqYMatrix;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DstabPackage.BASE_DSTAB_NETWORK__NEG_SEQ_YMATRIX, oldNegSeqYMatrix, negSeqYMatrix));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isYMatrixDirty() {
		return yMatrixDirty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setYMatrixDirty(boolean newYMatrixDirty) {
		boolean oldYMatrixDirty = yMatrixDirty;
		yMatrixDirty = newYMatrixDirty;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DstabPackage.BASE_DSTAB_NETWORK__YMATRIX_DIRTY, oldYMatrixDirty, yMatrixDirty));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StaticLoadModel getStaticLoadModel() {
		return staticLoadModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStaticLoadModel(StaticLoadModel newStaticLoadModel) {
		StaticLoadModel oldStaticLoadModel = staticLoadModel;
		staticLoadModel = newStaticLoadModel == null ? STATIC_LOAD_MODEL_EDEFAULT : newStaticLoadModel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_MODEL, oldStaticLoadModel, staticLoadModel));
	}

	@Override
	public StaticLoadModel getReactiveStaticLoadModel() {
		return reactiveStaticLoadModel;
	}

	@Override
	public void setReactiveStaticLoadModel(StaticLoadModel newStaticLoadModel) {
		reactiveStaticLoadModel = newStaticLoadModel == null ? REACTIVE_STATIC_LOAD_MODEL_EDEFAULT : newStaticLoadModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getStaticLoadSwitchVolt() {
		return staticLoadSwitchVolt;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStaticLoadSwitchVolt(double newStaticLoadSwitchVolt) {
		double oldStaticLoadSwitchVolt = staticLoadSwitchVolt;
		staticLoadSwitchVolt = newStaticLoadSwitchVolt;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_SWITCH_VOLT, oldStaticLoadSwitchVolt, staticLoadSwitchVolt));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getStaticLoadSwitchDeadZone() {
		return staticLoadSwitchDeadZone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStaticLoadSwitchDeadZone(double newStaticLoadSwitchDeadZone) {
		double oldStaticLoadSwitchDeadZone = staticLoadSwitchDeadZone;
		staticLoadSwitchDeadZone = newStaticLoadSwitchDeadZone;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_SWITCH_DEAD_ZONE, oldStaticLoadSwitchDeadZone, staticLoadSwitchDeadZone));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getNetEqnIterationNoEvent() {
		return netEqnIterationNoEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setNetEqnIterationNoEvent(int newNetEqnIterationNoEvent) {
		int oldNetEqnIterationNoEvent = netEqnIterationNoEvent;
		netEqnIterationNoEvent = newNetEqnIterationNoEvent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DstabPackage.BASE_DSTAB_NETWORK__NET_EQN_ITERATION_NO_EVENT, oldNetEqnIterationNoEvent, netEqnIterationNoEvent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getNetEqnIterationWithEvent() {
		return netEqnIterationWithEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setNetEqnIterationWithEvent(int newNetEqnIterationWithEvent) {
		int oldNetEqnIterationWithEvent = netEqnIterationWithEvent;
		netEqnIterationWithEvent = newNetEqnIterationWithEvent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DstabPackage.BASE_DSTAB_NETWORK__NET_EQN_ITERATION_WITH_EVENT, oldNetEqnIterationWithEvent, netEqnIterationWithEvent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isSaturatedMachineParameter() {
		return saturatedMachineParameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSaturatedMachineParameter(boolean newSaturatedMachineParameter) {
		boolean oldSaturatedMachineParameter = saturatedMachineParameter;
		saturatedMachineParameter = newSaturatedMachineParameter;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DstabPackage.BASE_DSTAB_NETWORK__SATURATED_MACHINE_PARAMETER, oldSaturatedMachineParameter, saturatedMachineParameter));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public IDStabNetChangeListener getNetChangeListener() {
		return netChangeListener;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setNetChangeListener(IDStabNetChangeListener newNetChangeListener) {
		IDStabNetChangeListener oldNetChangeListener = netChangeListener;
		netChangeListener = newNetChangeListener;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DstabPackage.BASE_DSTAB_NETWORK__NET_CHANGE_LISTENER, oldNetChangeListener, netChangeListener));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<DynamicSimuEvent> getDynamicEventList() {
		if (dynamicEventList == null) {
			dynamicEventList = new EObjectContainmentEList<DynamicSimuEvent>(DynamicSimuEvent.class, this, DstabPackage.BASE_DSTAB_NETWORK__DYNAMIC_EVENT_LIST);
		}
		return dynamicEventList;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<IRelayModel> getRelayModelList() {
		if (relayModelList == null) {
			relayModelList = new EObjectContainmentEList<IRelayModel>(IRelayModel.class, this, DstabPackage.BASE_DSTAB_NETWORK__RELAY_MODEL_LIST);
		}
		return relayModelList;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<TBus> getGenWithoutBusList() {
		if (genWithoutBusList == null) {
			genWithoutBusList = new EObjectContainmentEList<TBus>(BaseDStabBus.class, this, DstabPackage.BASE_DSTAB_NETWORK__GEN_WITHOUT_BUS_LIST);
		}
		return genWithoutBusList;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public BaseDStabBus<DStabGen, DStabLoad> getDStabBus(String busId) {
		return (BaseDStabBus<DStabGen, DStabLoad>)this.getBus(busId);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public DStabBranch getDStabBranch(String branchId) {
		return (DStabBranch)getBranch(branchId);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public Machine addMachine(Machine machine, String busId, String genId)  throws InterpssException {
		BaseDStabBus<?,?> bus = getDStabBus(busId);
		if (bus == null || bus.getContributeGen(genId) == null) {
			throw new InterpssException("The bus/gen for addMachine() cannot be found, busId/genId: " + busId + "/" + genId);
		}
		
		DStabGen gen = (DStabGen)bus.getContributeGen(genId);
		gen.setMach(machine);
		return machine;
	}

	
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public Machine getMachine(String machId) {
		
		for (Bus b : this.getBusList()) {
			BaseDStabBus<?,?> bus = (BaseDStabBus<?,?>)b;
			if(bus.getMachine(machId)!=null)
				return bus.getMachine(machId);
		}
		return null;	
	}

	private DynamicBusDevice getDBusDevice(String id) {
		for (Bus b : this.getBusList()) {
			BaseDStabBus<?,?> bus = (BaseDStabBus<?,?>)b;
			if (bus.getDynamicBusDevice(id) != null)
				return bus.getDynamicBusDevice(id);
		}
		return null;	
	}

	private DynamicBusDevice addDynamicBusDevice(DynamicBusDevice device, String busId) {
		BaseDStabBus<?,?> bus = getDStabBus(busId);
		if (bus == null) {
			throw new InterpssRuntimeException("The bus for addDynamicBusDevice() cannot be found, id: " + busId);
		}
		// multiple machine and devices should be allowed
//		if (bus.getMachine() != null || bus.getScriptDynamicBusDevice() != null) {
//			throw new InvalidOperationException("The bus already has a device for addDynamicBusDevice(), id: " + busId);
//		}
		bus.addDynamicBusDevice(device);
		return device;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
//	public boolean isScriptDynamicBusDeviceBus(DStabBus bus) {
//		return bus.getScriptDynamicBusDevice() != null;
//	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public ScriptDynamicBusDevice addScriptDynamicBusDevice(ScriptDynamicBusDevice device, String busId) {
		return (ScriptDynamicBusDevice)addDynamicBusDevice(device, busId);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public ScriptDynamicBusDevice getScriptDynamicBusDevice(String deviceId) {
		return (ScriptDynamicBusDevice)getDBusDevice(deviceId);	
	}
	
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
//	public void removeDBusDevice(String id) {
//		DynamicBusDevice d = getDBusDevice(id);
//		if (d != null) {
//			for (Bus b : this.getBusList()) {
//				DStabBus bus = (DStabBus)b;
//				bus.getDynamicBusDeviceList().remove(d);
//				//d.getDeviceBus().setDeviceAdjElement(null);
//			}
//		}	
//		else
//			throw new InvalidParameterException("DStabilityNetwork.removeMachine(), machine not found, id: " + id);
//	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public DynamicSimuEvent addDynamicEvent(DynamicSimuEvent dEvent, String eventId) {
		if (getDynamicEvent(eventId) != null) {
			log.error("The event already exists, id: " + eventId);
			return null;
		}
		dEvent.setId(eventId);
		getDynamicEventList().add(dEvent);
		return dEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public DynamicSimuEvent getDynamicEvent(String eventId) {
		for( DynamicSimuEvent e : getDynamicEventList()) {
			if (e.getId().equals(eventId))
				return e;
		}
		return null;	
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
//	public void removeDEvent(String eventId) {
//		DynamicEvent e = getDEvent(eventId);
//		if (e != null) {
//			getDynamicEventList().remove(e);
//		}	
//		else
//			throw new InvalidParameterException("DStabilityNetwork.removeDEvent(), event not found, id: " + eventId);
//	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public void removeAllDEvent() {
		getDynamicEventList().clear();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public boolean initDStabNet() {
		boolean initFlag = true;
		
        // Direct network callers get the same preparation as the default solver.
        if (!prepareDStabModels()) return false;

		// pre-process the dynamic models which leads to addition of buses or dynamic models in the network.
		// The busList or dynamic models of certain buses would be changed after this pre-processing step
		
		//Use a temporary list to avoid ConcurrentModificationException
		List<BaseDStabBus<?,?>> infoOnlyDynBusList = new ArrayList<>();
		
		for ( BaseDStabBus<?,?> bus : getBusList() ) {	
			// initialize info only dynamic models
			if(bus.isActive()  && bus.getInfoOnlyDynModel()!=null){
				infoOnlyDynBusList.add(bus);
			}
		}
		
		for(BaseDStabBus<?,?> bus : infoOnlyDynBusList) {
			if(!bus.getInfoOnlyDynModel().initStates(bus)){
				initFlag  =false;
			}
		}
		
		
		
		for ( BaseDStabBus<?,?> bus : getBusList() ) {

			//only the active buses will be initialized
			if(bus.isActive()){
				// set bus initial vaule 
				bus.setInitLoad(new Complex(bus.getLoadP(), bus.getLoadQ()));
				bus.setInitVoltMag(bus.getVoltageMag());
				
				//reset sequence Load equivalent
				bus.resetSeqEquivLoad();
				
				// init bus dynamic signal calculation, 
				// for example, bus Frequency measurement
				bus.initStates();  
				
				// protection/relay models are stored in the DynamicBusDeviceList
				if(bus.getDynamicBusDeviceList()!=null){
					for(DynamicBusDevice dynDevice: bus.getDynamicBusDeviceList()){
						if(dynDevice.isActive() && dynDevice.getDeviceType() != DynamicBusDeviceType.DYNAMIC_GENERATOR){
							if(!dynDevice.initStates(bus)) {
								initFlag  =false;
						   }
						}
					}
				}
				
				if (bus.getScriptDynamicBusDevice() != null) {
					ScriptDynamicBusDevice device = bus.getScriptDynamicBusDevice();
					if(device.isActive())
						if(!device.initStates(bus))
							initFlag  =false;
					
				}
				
				else {
				    
					
			
					double totalDynLoadPercent = 0;
					Complex totalDynLoadPQ = new Complex(0,0);
					if(bus.isLoad() && bus.getDynLoadModelList().size()>0){
						for(DynLoadModel load:bus.getDynLoadModelList()){
							if(load.isActive()){
								totalDynLoadPercent += load.getLoadPercent(); 
						
							}
						}
						
						// check the value of totalDynLoadPercent, it must be <=100.0; otherwise rescale it down to 100.
						if(totalDynLoadPercent>100.0){
							log.error("The total dynamic loads accout for more than 100% of the bus load. Rescaled down to 100%");
							for(DynLoadModel load:bus.getDynLoadModelList()){
								if(load.isActive()){
							       load.setLoadPercent(load.getLoadPercent()*100.0/totalDynLoadPercent);
								}
							}
							totalDynLoadPercent = 100.0;
						}
						
						// the init load is only available after initialization
						for(DynLoadModel load:bus.getDynLoadModelList()){
							if(load.isActive()){
						      if (!load.initStates()) initFlag =false;
						       totalDynLoadPQ = totalDynLoadPQ.add(load.getInitLoadPQ());
							}
						}
						
						Complex orginalLoadPQ  = bus.calNetLoadResults();
						
						bus.setNetLoadResults(orginalLoadPQ.subtract(totalDynLoadPQ));
						
						
						// add the dynamic load models to dynamicBusDeviceList
						bus.getDynamicBusDeviceList().addAll(bus.getDynLoadModelList());
						
					}
					
			
					if (bus.getContributeGenList() != null) {
                        if(bus.getContributeGenList().size()>0){
                           for(DStabGen gen:bus.getContributeGenList()){
               
                        	   if(gen.isActive()){
                               	// this will include initializing all controllers
                                   if (!gen.getDynamicGenDevice().initStates(bus))  
                                         initFlag = false;
                             }
                        	   
                           }
                       }
					}
				}
		     }

		}
		
		// initial dynamic event
		for ( DynamicSimuEvent devent : getDynamicEventList() ) {
			if (devent.getType() == DynamicSimuEventType.SET_POINT_CHANGE) {
				SetPointChangeEvent sEvent = (SetPointChangeEvent)devent.getBusDynamicEvent();
                var eventMachine=getMachine(sEvent.getMachId());
                if(eventMachine==null)throw new IllegalArgumentException("Missing set-point event machine: "+sEvent.getMachId());
                sEvent.setBus(eventMachine.getDStabBus());
                if(devent instanceof com.interpss.dstab.devent.impl.DynamicSimuEventImpl eventImpl)eventImpl.setSetPointApplied(false);
			}
		}

		initStaticLoadModel();
		
		// for positive Y-matrix
		formYMatrix4DStab();
		
		
		//System.out.println(this.getYMatrix());
		if(initFlag) this.isInitialized = true;
		return true;
	}

    private void beginDynamicModelInventory() {
        dynamicModelInventoryValid = false;
        collectingDynamicModelInventory = true;
        dynamicModelInventoryBuildCount++;
        hasGenWithoutMach = false;
        genWithoutMachBusList.clear();
        generatorsWithoutDynamicModels.clear();
    }

    // Called from each bus's ordinary data check; no second network scan.
    void recordGeneratorWithoutDynamicModel(DStabGen gen) {
        if (!collectingDynamicModelInventory) return;
        generatorsWithoutDynamicModels.add(gen);
        var bus = (BaseDStabBus<DStabGen, DStabLoad>) gen.getParentBus();
        if (!genWithoutMachBusList.contains(bus)) genWithoutMachBusList.add(bus);
        hasGenWithoutMach = true;
    }

    private void ensureDynamicModelInventory() {
        if (dynamicModelInventoryValid) return;
        // One lightweight fallback pass when checking was bypassed or invalidated.
        beginDynamicModelInventory();
        try {
            for (BaseDStabBus<?, ?> bus : getBusList()) if (bus.isActive())
                for (DStabGen gen : bus.getContributeGenList())
                    if (gen.isActive() && gen.getDynamicGenDevice() == null)
                        recordGeneratorWithoutDynamicModel(gen);
            dynamicModelInventoryValid = true;
        } finally {
            collectingDynamicModelInventory = false;
        }
    }

    @Override
    public boolean prepareDStabModels() {
        ensureDynamicModelInventory();
        if (!hasGenWithoutMach) return true;
        if (!isAllowGenWithoutMach() || !isLfConverged() || isDStabNetInitialized()) {
            log.error("Cannot net generators without dynamic models: enable netting, solve "
                    + "power flow, and prepare before dynamic initialization. Buses: "
                    + genWithoutMachBusList.stream().map(BaseDStabBus::getId).toList());
            return false;
        }
        // Read final solved powers only now; P/Q changes do not invalidate the
        // model inventory. Validate every pending unit before mutating any unit.
        for (DStabGen gen : generatorsWithoutDynamicModels)
            if (gen.getGen() == null || gen.getGen().isNaN() || gen.getGen().isInfinite()) {
                log.error("Invalid solved generator power at " + gen.getParentBus().getId() + "/" + gen.getId());
                return false;
            }
        var pending = new java.util.LinkedHashMap<BaseDStabBus<DStabGen,DStabLoad>, List<DStabGen>>();
        for (DStabGen gen : generatorsWithoutDynamicModels) {
            var bus = (BaseDStabBus<DStabGen,DStabLoad>) gen.getParentBus();
            pending.computeIfAbsent(bus, key -> new ArrayList<>()).add(gen);
        }
        for (var entry : pending.entrySet()) {
            var bus = entry.getKey();
            double p = 0., q = 0.;
            String id = "Gen-Equiv";
            int suffix = 2;
            while (bus.getContributeLoad(id) != null) id = "Gen-Equiv-" + suffix++;
            for (DStabGen gen : entry.getValue()) {
                p += gen.getGen().getReal(); q += gen.getGen().getImaginary();
                log.warn("Netting generator without dynamic model before load conversion: "
                        + bus.getId() + "/" + gen.getId() + ", P/Q=" + gen.getGen() + ", load=" + id);
                gen.setStatus(false);
            }
            DStabLoad load = DStabObjectFactory.createDStabLoad(id);
            load.setCode(AclfLoadCode.CONST_P);
            load.setStatus(true);
            load.setLoadCP(new Complex(-p, -q));
            bus.getContributeLoadList().add(load);
            if (bus.getLoadCode() == AclfLoadCode.NON_LOAD) bus.setLoadCode(AclfLoadCode.CONST_P);
            // Refresh aggregate metadata without resetting a solved voltage or
            // redistributing the surviving generators' solved powers.
            Complex remaining = Complex.ZERO;
            boolean active = false;
            for (DStabGen gen : bus.getContributeGenList()) if (gen.isActive()) {
                remaining = remaining.add(gen.getGen()); active = true;
            }
            if (!active) bus.setGenCode(AclfGenCode.NON_GEN);
            bus.setGenP(remaining.getReal()); bus.setGenQ(remaining.getImaginary());
            if (!bus.initContributeLoad(false)) return false;
        }
        // The only changes above were the recorded conversions; consume the plan
        // directly instead of scanning the network again.
        generatorsWithoutDynamicModels.clear();
        genWithoutMachBusList.clear();
        hasGenWithoutMach = false;
        dynamicModelInventoryValid = true;
        return true;
    }

	private void initStaticLoadModel() {
		//initialize static load models
		if(!this.isStaticLoadIncludedInYMatrix) {
			if(this.getStaticLoadModel()==StaticLoadModel.CONST_P) {
				if(this.getReactiveStaticLoadModel()==StaticLoadModel.CONST_P) { 
					for ( BaseDStabBus<?,?> bus : getBusList() ) {
						//process only the load buses
						if(bus.isLoad()){
							bus.setInitConstPStaticLoad(bus.calNetLoadResults());
						}
				     }
				}
				else if(this.getReactiveStaticLoadModel()==StaticLoadModel.CONST_I) {
					for ( BaseDStabBus<?,?> bus : getBusList() ) {
						//process only the load buses
						if(bus.isLoad()){
							bus.setInitConstPStaticLoad(new Complex(bus.calNetLoadResults().getReal(),0));
							bus.setInitConstIStaticLoad(new Complex(0,bus.calNetLoadResults().getImaginary()));
						}
				     }
				}
				else if(this.getReactiveStaticLoadModel()==StaticLoadModel.CONST_Z) {
					for ( BaseDStabBus<?,?> bus : getBusList() ) {
						//process only the load buses
						if(bus.isLoad()){
							bus.setInitConstPStaticLoad(new Complex(bus.calNetLoadResults().getReal(),0));
							bus.setInitConstZStaticLoad(new Complex(0,bus.calNetLoadResults().getImaginary()));
						}
				     }
				}
		    }
			else if(this.getStaticLoadModel()==StaticLoadModel.CONST_I) {
				if(this.getReactiveStaticLoadModel()==StaticLoadModel.CONST_P) { 
					for ( BaseDStabBus<?,?> bus : getBusList() ) {
						//process only the load buses
						if(bus.isLoad()){
							bus.setInitConstIStaticLoad(new Complex(bus.calNetLoadResults().getReal(),0));
							bus.setInitConstPStaticLoad(new Complex(0,bus.calNetLoadResults().getImaginary()));
						}
				     }
				}
				else if(this.getReactiveStaticLoadModel()==StaticLoadModel.CONST_I) {
					for ( BaseDStabBus<?,?> bus : getBusList() ) {
						//process only the load buses
						if(bus.isLoad()){
							
							bus.setInitConstIStaticLoad(bus.calNetLoadResults());
						}
				     }
				}
				else if(this.getReactiveStaticLoadModel()==StaticLoadModel.CONST_Z) {
					for ( BaseDStabBus<?,?> bus : getBusList() ) {
						//process only the load buses
						if(bus.isLoad()){
							bus.setInitConstIStaticLoad(new Complex(bus.calNetLoadResults().getReal(),0));
							bus.setInitConstZStaticLoad(new Complex(0,bus.calNetLoadResults().getImaginary()));
						}
				     }
				}
			}
			else if(this.getStaticLoadModel()==StaticLoadModel.CONST_Z) {
				if(this.getReactiveStaticLoadModel()==StaticLoadModel.CONST_P) { 
					for ( BaseDStabBus<?,?> bus : getBusList() ) {
						//process only the load buses
						if(bus.isLoad()){
							bus.setInitConstZStaticLoad(new Complex(bus.calNetLoadResults().getReal(),0));
							bus.setInitConstPStaticLoad(new Complex(0,bus.calNetLoadResults().getImaginary()));
						}
				     }
				}
				else if(this.getReactiveStaticLoadModel()==StaticLoadModel.CONST_I) {
					for ( BaseDStabBus<?,?> bus : getBusList() ) {
						//process only the load buses
						if(bus.isLoad()){
							bus.setInitConstZStaticLoad(new Complex(bus.calNetLoadResults().getReal(),0));
							bus.setInitConstIStaticLoad(new Complex(0,bus.calNetLoadResults().getImaginary()));
						}
				     }
				}
				else if(this.getReactiveStaticLoadModel()==StaticLoadModel.CONST_Z) {
					for ( BaseDStabBus<?,?> bus : getBusList() ) {
						//process only the load buses
						if(bus.isLoad()){
							bus.setInitConstZStaticLoad(bus.calNetLoadResults());
						}
				     }
				}
			}
		}
	}
	
	
	public void formYMatrix4DStab(){
		this.yMatrix = formScYMatrix(SequenceCode.POSITIVE, ScBusModelType.DSTAB_SIMU, false);

		// formScYMatrix() starts from the generic ACSC/RAW generator source
		// impedances. For synchronous Machine devices, replace each RAW diagonal
		// term with the machine model's Norton admittance. Other DynamicGenDevice
		// implementations may intentionally use the RAW impedance when forming
		// their current source, so their matrix term must remain unchanged.
		for (BaseDStabBus<?, ?> bus : getBusList()) {
			if (!bus.isActive()) continue;
			Complex correction = Complex.ZERO;
			for (DStabGen gen : bus.getContributeGenList()) {
				if (!gen.isActive()) continue;
				if (gen.getDynamicGenDevice() instanceof Machine machine) {
					Complex rawGenY = Complex.ZERO;
					if (gen.getPosGenZ() != null) {
						rawGenY = Complex.ONE.divide(
								gen.getPosGenZ().multiply(gen.getZMultiFactor()));
					}
					correction = correction.add(machine.getYgen().subtract(rawGenY));
				}
			}
			if (correction.abs() > 0.0) {
				this.yMatrix.addToA(correction, bus.getSortNumber(), bus.getSortNumber());
			}
		}
		
		// add the equivalent admittance of dynamic load models to the Ymatrix
				for ( BaseDStabBus<?,?> bus : getBusList() ) {
					if(bus.isActive() && bus.isLoad()){
						if(bus.getDynLoadModelList().size()>0){
							Complex dynLoadEquivY = new Complex(0,0);
						
							for(DynLoadModel load:bus.getDynLoadModelList()){
								if(load.isActive()){
									dynLoadEquivY = dynLoadEquivY.add(load.getPosSeqEquivY());
									//TODO when a compensation shuntY is needed, the remaining loadQ is negative, 
									// NetLoadResults = orginalLoadPQ.subtract(totalDynLoadPQ). NetLoadResults includes the compensation reactive power
									// With the existing load conversion mechanism, NetLoadResults are converted to 
									// equivalent addmittances. Thus, it is not necessary to add it to the Ymatrix again here.
									
									// The info of compShuntY is only needed when the AC motor is tripped/reconnected to the system.
									//if(load.getCompShuntY()!=null)
									//	dynLoadEquivY = dynLoadEquivY.add(load.getCompShuntY());
								}
							}
							
							this.getYMatrix().addToA(dynLoadEquivY, bus.getSortNumber(), bus.getSortNumber());
						}
					}
				}
				
		
		
		setYMatrixDirty(true);
	}
	

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public boolean solveNetEqn() {
	  //	int cnt = netChange? 
	  //			getNetEqnIterationWithEvent() : getNetEqnIterationNoEvent();
	  // Update 04/26/2015 network solution iteration and convergence checking are performed outside
	  // network solution is done for once.
	  	return solveNetEqn_impl();
	}

    public interface ExperimentVoltageObserver {void observe(int partition,int index,BaseDStabBus<?,?> bus,Complex solvedVoltage);}
    private ExperimentVoltageObserver experimentVoltageObserver;
    public void setExperimentVoltageObserver(ExperimentVoltageObserver observer) {experimentVoltageObserver=observer;}
    public int getExperimentWorkerCount() {return 1;}
    private static final boolean PRIMITIVE_CURRENT_EXPERIMENT=Boolean.getBoolean("ipss.experiment.primitiveCurrentHandoff");
    private double[] primitiveCurrentWorkspace;
    private long primitiveCurrentInventoryVersion=Long.MIN_VALUE;
    private boolean primitiveCurrentInventorySupported;
    private String primitiveCurrentReason="not evaluated";
    private long primitiveCurrentSolves,primitiveStaticRows;
    public long getPrimitiveCurrentSolveCount(){return primitiveCurrentSolves;}
    public long getPrimitiveStaticRowCount(){return primitiveStaticRows;}
    public String getPrimitiveCurrentReason(){return primitiveCurrentReason;}

    private final DStabCurrentBuffer publicationGuard = new DStabCurrentBuffer();
    private boolean primitiveCurrentAssemblyEligible() {
        return PRIMITIVE_CURRENT_EXPERIMENT && customBusCurTable == null
                && custom3SeqBusCurTable == null && publicationGuard.supports(this);
    }

    private long phaseSetup,phaseAssembly,phaseCustom,phaseSolve,phasePublish,phaseCalls;
    public Object getNetworkPhaseAudit(){return java.util.Map.of("calls",phaseCalls,
        "setup_s",phaseSetup/1.e9,"assembly_s",phaseAssembly/1.e9,"custom_s",phaseCustom/1.e9,
        "solve_s",phaseSolve/1.e9,"publish_s",phasePublish/1.e9);}
	private boolean solveNetEqn_impl() {
        long phase=System.nanoTime();
        BaseDStabBus<?,?>[] runtimeBuses=dynamicRuntimeBuses();
	  	if ( !isBusNumberArranged() ) {
			//this.accept(CoreObjectFactory.createBusNoArrangeVisitor());
	  		this.arrangeBusNumber();
		}		
	
	  	if (isYMatrixDirty()) {
			// form y-matrix and LU, we add gen equivelenet Z here
			try {
				getYMatrix().factorization(Constants.Matrix_LU_Tolerance);
				setYMatrixDirty(false);
			} catch (IpssNumericException e) {
				return false;
			}
		}
		
	  	//for (int n = 0; n < itrCnt; n++ ) {
	  		try {
                phaseSetup+=System.nanoTime()-phase;phase=System.nanoTime();
                boolean primitiveAssembly=primitiveCurrentAssemblyEligible();
                com.interpss.core.sparse.impl.klu.JKLUSparseEqnComplexImpl primitiveMatrix=primitiveAssembly
                    ?(com.interpss.core.sparse.impl.klu.JKLUSparseEqnComplexImpl)getYMatrix():null;
                if(primitiveAssembly) {
                    int dimension=primitiveMatrix.getDimension();
                    if(primitiveCurrentWorkspace==null || primitiveCurrentWorkspace.length!=2*dimension)
                        primitiveCurrentWorkspace=new double[2*dimension];
                    // Preserve untouched/inactive rows of the ordinary equation-vector interface.
                    for(int row=0;row<dimension;row++) {
                        Complex value=primitiveMatrix.getX(row);
                        primitiveCurrentWorkspace[2*row]=value==null?0.:value.getReal();
                        primitiveCurrentWorkspace[2*row+1]=value==null?0.:value.getImaginary();
                    }
                }
			  	// Calculate and set generator injection current
				for(int busIndex=0, busCount=runtimeBuses.length; busIndex<busCount; busIndex++) {
                    BaseDStabBus<?,?> bus=runtimeBuses[busIndex];
					//TODO to consider bus status

					if(bus.isActive()){
                      if(primitiveAssembly && ((BaseDStabBusImpl<?,?>)bus).writeStaticCurrentExperiment(
                              primitiveCurrentWorkspace,2*bus.getSortNumber())) {
                          primitiveStaticRows++;continue;
                      }
					  Complex iInject= bus.injCurDynamic(getStaticLoadModel(), 
							getStaticLoadSwitchVolt(), getStaticLoadSwitchDeadZone());
					  
					  if(iInject == null){
						  throw new Error (bus.getId()+" current injection is null");
					  }
					  else if(iInject.isNaN()){
						  throw new Error (bus.getId()+" current injection is NAN");
					  }
					  
                      if(primitiveAssembly) {
                          int offset=2*bus.getSortNumber();
                          primitiveCurrentWorkspace[offset]=iInject.getReal();primitiveCurrentWorkspace[offset+1]=iInject.getImaginary();
                      } else {
					  getYMatrix().setBi(iInject, bus.getSortNumber());
                      }
					}
				}
				
				//add customized bus current injection, which is used in hybrid simulation or 
				//for adding user new defined models, which is represented as current injections in dynamic simulation
				phaseAssembly+=System.nanoTime()-phase;phase=System.nanoTime();
                addCustomBusCurrentInj();
                phaseCustom+=System.nanoTime()-phase;phase=System.nanoTime();
				
				//System.out.println(getYMatrix());
                if(primitiveAssembly) {
                    primitiveMatrix.getJkluSolver().solveInterleavedInPlace(primitiveCurrentWorkspace);
                    // Publish all solved rows before voltage observers or bus notifications run.
                    for(int row=0;row<primitiveMatrix.getDimension();row++)
                        primitiveMatrix.setBi(new Complex(primitiveCurrentWorkspace[2*row],primitiveCurrentWorkspace[2*row+1]),row);
                    primitiveCurrentSolves++;
                } else getYMatrix().solveEqn();
	
				phaseSolve+=System.nanoTime()-phase;phase=System.nanoTime();
                // update bus voltage and machine Pe
				for(int busIndex=0, busCount=runtimeBuses.length; busIndex<busCount; busIndex++) {
                    BaseDStabBus<?,?> bus=runtimeBuses[busIndex];
					if(bus.isActive()){
						Complex v = getYMatrix().getX(bus.getSortNumber());

						if(!v.isNaN()){
						  double solvedMagnitude=v.abs();
                          if(solvedMagnitude>10) {
							  log.error("Network solution step diverged! Bus votlage magnitude > 10 @"+bus.getId());
						      return false;
						  }
                          else {
                              if(bus instanceof com.interpss.core.aclf.impl.BaseAclfBusImpl<?,?> impl)
                                  impl.setVoltageWithDeferredAngle(v,solvedMagnitude);
                              else bus.setVoltage(v);
                              if(experimentVoltageObserver!=null)experimentVoltageObserver.observe(0,busIndex,bus,
                                  bus.getClass()==DStabBusImpl.class && !isPolarCoordinate() && !((DStabBusImpl)bus).eNotificationRequired()
                                  ? v : null);
                          }
			
						  //TODO separate the updateDynamicAttributes operation from network solution
						  // such that both parts can be used or implemented more flexibly. 
						  // this operation is moved to the nextStep() in dstabSolverImpl.
						 // bus.updateDynamicAttributes(netChange);
						}
						else
							 throw new Error (bus.getId()+" solution voltage is NaN");
					}
				}
	  			
	  		} 
	  		catch (IpssNumericException e) {
	  			log.error(e.toString());
	  			return false;
	  		}
	  		catch (InterpssException e) {
	  			log.error(e.toString());
	  			return false;
	  		}
	 	//}
	  	phasePublish+=System.nanoTime()-phase;phaseCalls++;
        return true;
	}
	
	/**
	 * <!-- begin-user-doc -->
	 * first the positive sequence current injection values will be added by default, then the 
	 * three-sequence current values will be considered. 
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
    private Hashtable<String,Complex> boundCurrentTable;
    private long boundCurrentVersion=Long.MIN_VALUE;
    private String[] boundCurrentKeys=new String[0];
    private BaseDStabBus<?,?>[] boundCurrentBuses=new BaseDStabBus<?,?>[0];
	@Override
	public void addCustomBusCurrentInj() {
        if (getClass()==com.interpss.dstab.impl.DStabilityNetworkImpl.class
                && customBusCurTable != null && customBusCurTable.getClass() == Hashtable.class
                && !Boolean.getBoolean("ipss.experiment.disableBoundCurrent")) {
            int count=customBusCurTable.size();
            if (boundCurrentTable!=customBusCurTable || boundCurrentVersion!=runtimeMembershipVersion
                    || boundCurrentKeys.length!=count) {
                boundCurrentTable=customBusCurTable;boundCurrentVersion=runtimeMembershipVersion;
                boundCurrentKeys=new String[count];boundCurrentBuses=new BaseDStabBus<?,?>[count];
            }
            int index=0;
            for (var entry:customBusCurTable.entrySet()) {
                if(boundCurrentVersion!=runtimeMembershipVersion) {
                    java.util.Arrays.fill(boundCurrentKeys,null);boundCurrentVersion=runtimeMembershipVersion;
                }
                String id=entry.getKey();
                BaseDStabBus<?,?> bus;
                if(index<boundCurrentKeys.length && id.equals(boundCurrentKeys[index])) {
                    bus=boundCurrentBuses[index];
                } else {
                    bus=getDStabBus(id);
                    if(index<boundCurrentKeys.length) {
                        boundCurrentKeys[index]=id;boundCurrentBuses[index]=bus;
                    }
                }
                getYMatrix().addToB(customBusCurTable==boundCurrentTable?entry.getValue():customBusCurTable.get(id),bus.getSortNumber());
                index++;
            }
            return;
        }
		if(customBusCurTable!=null){
			for(String busId:customBusCurTable.keySet()){
				BaseDStabBus<?,?> bus=this.getDStabBus(busId);
			    getYMatrix().addToB(customBusCurTable.get(busId), bus.getSortNumber());
			}
		}
		else if (this.custom3SeqBusCurTable!=null){
			for(String busId:this.custom3SeqBusCurTable.keySet()){
				BaseDStabBus<?,?> bus=this.getDStabBus(busId);
			    getYMatrix().addToB(this.custom3SeqBusCurTable.get(busId).b_1, bus.getSortNumber());
			}
		}
		
	}
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	@Override
	public void setCustomBusCurrInjHashtable(Hashtable<String,Complex> customBusCurTable){
		this.customBusCurTable = customBusCurTable;
	}
	
	@Override
	public Hashtable<String, Complex> getCustomBusCurrInjHashtable() {
		
		return this.customBusCurTable;
	}	

	/**
	 * The default value of the '{@link #isYMatrixDirty() <em>YMatrix Dirty</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isYMatrixDirty()
	 * @generated
	 * @ordered
	 */
	protected static final boolean YMATRIX_DIRTY_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isYMatrixDirty() <em>YMatrix Dirty</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isYMatrixDirty()
	 * @generated
	 * @ordered
	 */
	protected boolean yMatrixDirty = YMATRIX_DIRTY_EDEFAULT;

	/**
	 * The default value of the '{@link #getStaticLoadModel() <em>Static Load Model</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaticLoadModel()
	 * @generated
	 * @ordered
	 */
	protected static final StaticLoadModel STATIC_LOAD_MODEL_EDEFAULT = StaticLoadModel.CONST_Z;

	/**
	 * The cached value of the '{@link #getStaticLoadModel() <em>Static Load Model</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaticLoadModel()
	 * @generated
	 * @ordered
	 */
	protected StaticLoadModel staticLoadModel = STATIC_LOAD_MODEL_EDEFAULT;

	protected static final StaticLoadModel REACTIVE_STATIC_LOAD_MODEL_EDEFAULT = StaticLoadModel.CONST_Z;

	protected StaticLoadModel reactiveStaticLoadModel = REACTIVE_STATIC_LOAD_MODEL_EDEFAULT;

	/**
	 * The default value of the '{@link #getStaticLoadSwitchVolt() <em>Static Load Switch Volt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaticLoadSwitchVolt()
	 * @generated
	 * @ordered
	 */
	protected static final double STATIC_LOAD_SWITCH_VOLT_EDEFAULT = 0.65;

	/**
	 * The cached value of the '{@link #getStaticLoadSwitchVolt() <em>Static Load Switch Volt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaticLoadSwitchVolt()
	 * @generated
	 * @ordered
	 */
	protected double staticLoadSwitchVolt = STATIC_LOAD_SWITCH_VOLT_EDEFAULT;

	/**
	 * The default value of the '{@link #getStaticLoadSwitchDeadZone() <em>Static Load Switch Dead Zone</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaticLoadSwitchDeadZone()
	 * @generated
	 * @ordered
	 */
	protected static final double STATIC_LOAD_SWITCH_DEAD_ZONE_EDEFAULT = 0.05;

	/**
	 * The cached value of the '{@link #getStaticLoadSwitchDeadZone() <em>Static Load Switch Dead Zone</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaticLoadSwitchDeadZone()
	 * @generated
	 * @ordered
	 */
	protected double staticLoadSwitchDeadZone = STATIC_LOAD_SWITCH_DEAD_ZONE_EDEFAULT;

	/**
	 * The default value of the '{@link #getNetEqnIterationNoEvent() <em>Net Eqn Iteration No Event</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNetEqnIterationNoEvent()
	 * @generated
	 * @ordered
	 */
	protected static final int NET_EQN_ITERATION_NO_EVENT_EDEFAULT = 3;

	/**
	 * The cached value of the '{@link #getNetEqnIterationNoEvent() <em>Net Eqn Iteration No Event</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNetEqnIterationNoEvent()
	 * @generated
	 * @ordered
	 */
	protected int netEqnIterationNoEvent = NET_EQN_ITERATION_NO_EVENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getNetEqnIterationWithEvent() <em>Net Eqn Iteration With Event</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNetEqnIterationWithEvent()
	 * @generated
	 * @ordered
	 */
	protected static final int NET_EQN_ITERATION_WITH_EVENT_EDEFAULT = 5;

	/**
	 * The cached value of the '{@link #getNetEqnIterationWithEvent() <em>Net Eqn Iteration With Event</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNetEqnIterationWithEvent()
	 * @generated
	 * @ordered
	 */
	protected int netEqnIterationWithEvent = NET_EQN_ITERATION_WITH_EVENT_EDEFAULT;

	/**
	 * The default value of the '{@link #isSaturatedMachineParameter() <em>Saturated Machine Parameter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSaturatedMachineParameter()
	 * @generated
	 * @ordered
	 */
	protected static final boolean SATURATED_MACHINE_PARAMETER_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isSaturatedMachineParameter() <em>Saturated Machine Parameter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSaturatedMachineParameter()
	 * @generated
	 * @ordered
	 */
	protected boolean saturatedMachineParameter = SATURATED_MACHINE_PARAMETER_EDEFAULT;

	/**
	 * The default value of the '{@link #getNetChangeListener() <em>Net Change Listener</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNetChangeListener()
	 * @generated
	 * @ordered
	 */
	protected static final IDStabNetChangeListener NET_CHANGE_LISTENER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNetChangeListener() <em>Net Change Listener</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNetChangeListener()
	 * @generated
	 * @ordered
	 */
	protected IDStabNetChangeListener netChangeListener = NET_CHANGE_LISTENER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDynamicEventList() <em>Dynamic Event List</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDynamicEventList()
	 * @generated
	 * @ordered
	 */
	protected EList<DynamicSimuEvent> dynamicEventList;

	/**
	 * The cached value of the '{@link #getRelayModelList() <em>Relay Model List</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRelayModelList()
	 * @generated
	 * @ordered
	 */
	protected EList<IRelayModel> relayModelList;

	/**
	 * The cached value of the '{@link #getGenWithoutBusList() <em>Gen Without Bus List</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGenWithoutBusList()
	 * @generated
	 * @ordered
	 */
	protected EList<TBus> genWithoutBusList;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
//	public boolean isMachineBus(DStabBus bus) {
//		throw new UnsupportedOperationException();
//	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case DstabPackage.BASE_DSTAB_NETWORK__DYNAMIC_EVENT_LIST:
				return ((InternalEList<?>)getDynamicEventList()).basicRemove(otherEnd, msgs);
			case DstabPackage.BASE_DSTAB_NETWORK__RELAY_MODEL_LIST:
				return ((InternalEList<?>)getRelayModelList()).basicRemove(otherEnd, msgs);
			case DstabPackage.BASE_DSTAB_NETWORK__GEN_WITHOUT_BUS_LIST:
				return ((InternalEList<?>)getGenWithoutBusList()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case DstabPackage.BASE_DSTAB_NETWORK__DSTAB_NET_INITIALIZED:
				return isDStabNetInitialized();
			case DstabPackage.BASE_DSTAB_NETWORK__ALLOW_GEN_WITHOUT_MACH:
				return isAllowGenWithoutMach();
			case DstabPackage.BASE_DSTAB_NETWORK__YMATRIX:
				return getYMatrix();
			case DstabPackage.BASE_DSTAB_NETWORK__ZERO_SEQ_YMATRIX:
				return getZeroSeqYMatrix();
			case DstabPackage.BASE_DSTAB_NETWORK__NEG_SEQ_YMATRIX:
				return getNegSeqYMatrix();
			case DstabPackage.BASE_DSTAB_NETWORK__YMATRIX_DIRTY:
				return isYMatrixDirty();
			case DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_MODEL:
				return getStaticLoadModel();
			case DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_SWITCH_VOLT:
				return getStaticLoadSwitchVolt();
			case DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_SWITCH_DEAD_ZONE:
				return getStaticLoadSwitchDeadZone();
			case DstabPackage.BASE_DSTAB_NETWORK__NET_EQN_ITERATION_NO_EVENT:
				return getNetEqnIterationNoEvent();
			case DstabPackage.BASE_DSTAB_NETWORK__NET_EQN_ITERATION_WITH_EVENT:
				return getNetEqnIterationWithEvent();
			case DstabPackage.BASE_DSTAB_NETWORK__SATURATED_MACHINE_PARAMETER:
				return isSaturatedMachineParameter();
			case DstabPackage.BASE_DSTAB_NETWORK__NET_CHANGE_LISTENER:
				return getNetChangeListener();
			case DstabPackage.BASE_DSTAB_NETWORK__DYNAMIC_EVENT_LIST:
				return getDynamicEventList();
			case DstabPackage.BASE_DSTAB_NETWORK__RELAY_MODEL_LIST:
				return getRelayModelList();
			case DstabPackage.BASE_DSTAB_NETWORK__GEN_WITHOUT_BUS_LIST:
				return getGenWithoutBusList();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
		@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case DstabPackage.BASE_DSTAB_NETWORK__DSTAB_NET_INITIALIZED:
				setDStabNetInitialized((Boolean)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__ALLOW_GEN_WITHOUT_MACH:
				setAllowGenWithoutMach((Boolean)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__YMATRIX:
				setYMatrix((ISparseEqnComplex)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__ZERO_SEQ_YMATRIX:
				setZeroSeqYMatrix((ISparseEqnComplex)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__NEG_SEQ_YMATRIX:
				setNegSeqYMatrix((ISparseEqnComplex)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__YMATRIX_DIRTY:
				setYMatrixDirty((Boolean)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_MODEL:
				setStaticLoadModel((StaticLoadModel)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_SWITCH_VOLT:
				setStaticLoadSwitchVolt((Double)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_SWITCH_DEAD_ZONE:
				setStaticLoadSwitchDeadZone((Double)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__NET_EQN_ITERATION_NO_EVENT:
				setNetEqnIterationNoEvent((Integer)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__NET_EQN_ITERATION_WITH_EVENT:
				setNetEqnIterationWithEvent((Integer)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__SATURATED_MACHINE_PARAMETER:
				setSaturatedMachineParameter((Boolean)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__NET_CHANGE_LISTENER:
				setNetChangeListener((IDStabNetChangeListener)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__DYNAMIC_EVENT_LIST:
				getDynamicEventList().clear();
				getDynamicEventList().addAll((Collection<? extends DynamicSimuEvent>)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__RELAY_MODEL_LIST:
				getRelayModelList().clear();
				getRelayModelList().addAll((Collection<? extends IRelayModel>)newValue);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__GEN_WITHOUT_BUS_LIST:
				getGenWithoutBusList().clear();
				getGenWithoutBusList().addAll((Collection<? extends TBus>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case DstabPackage.BASE_DSTAB_NETWORK__DSTAB_NET_INITIALIZED:
				setDStabNetInitialized(DSTAB_NET_INITIALIZED_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__ALLOW_GEN_WITHOUT_MACH:
				setAllowGenWithoutMach(ALLOW_GEN_WITHOUT_MACH_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__YMATRIX:
				setYMatrix(YMATRIX_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__ZERO_SEQ_YMATRIX:
				setZeroSeqYMatrix(ZERO_SEQ_YMATRIX_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__NEG_SEQ_YMATRIX:
				setNegSeqYMatrix(NEG_SEQ_YMATRIX_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__YMATRIX_DIRTY:
				setYMatrixDirty(YMATRIX_DIRTY_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_MODEL:
				setStaticLoadModel(STATIC_LOAD_MODEL_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_SWITCH_VOLT:
				setStaticLoadSwitchVolt(STATIC_LOAD_SWITCH_VOLT_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_SWITCH_DEAD_ZONE:
				setStaticLoadSwitchDeadZone(STATIC_LOAD_SWITCH_DEAD_ZONE_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__NET_EQN_ITERATION_NO_EVENT:
				setNetEqnIterationNoEvent(NET_EQN_ITERATION_NO_EVENT_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__NET_EQN_ITERATION_WITH_EVENT:
				setNetEqnIterationWithEvent(NET_EQN_ITERATION_WITH_EVENT_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__SATURATED_MACHINE_PARAMETER:
				setSaturatedMachineParameter(SATURATED_MACHINE_PARAMETER_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__NET_CHANGE_LISTENER:
				setNetChangeListener(NET_CHANGE_LISTENER_EDEFAULT);
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__DYNAMIC_EVENT_LIST:
				getDynamicEventList().clear();
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__RELAY_MODEL_LIST:
				getRelayModelList().clear();
				return;
			case DstabPackage.BASE_DSTAB_NETWORK__GEN_WITHOUT_BUS_LIST:
				getGenWithoutBusList().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case DstabPackage.BASE_DSTAB_NETWORK__DSTAB_NET_INITIALIZED:
				return dStabNetInitialized != DSTAB_NET_INITIALIZED_EDEFAULT;
			case DstabPackage.BASE_DSTAB_NETWORK__ALLOW_GEN_WITHOUT_MACH:
				return allowGenWithoutMach != ALLOW_GEN_WITHOUT_MACH_EDEFAULT;
			case DstabPackage.BASE_DSTAB_NETWORK__YMATRIX:
				return YMATRIX_EDEFAULT == null ? yMatrix != null : !YMATRIX_EDEFAULT.equals(yMatrix);
			case DstabPackage.BASE_DSTAB_NETWORK__ZERO_SEQ_YMATRIX:
				return ZERO_SEQ_YMATRIX_EDEFAULT == null ? zeroSeqYMatrix != null : !ZERO_SEQ_YMATRIX_EDEFAULT.equals(zeroSeqYMatrix);
			case DstabPackage.BASE_DSTAB_NETWORK__NEG_SEQ_YMATRIX:
				return NEG_SEQ_YMATRIX_EDEFAULT == null ? negSeqYMatrix != null : !NEG_SEQ_YMATRIX_EDEFAULT.equals(negSeqYMatrix);
			case DstabPackage.BASE_DSTAB_NETWORK__YMATRIX_DIRTY:
				return yMatrixDirty != YMATRIX_DIRTY_EDEFAULT;
			case DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_MODEL:
				return staticLoadModel != STATIC_LOAD_MODEL_EDEFAULT;
			case DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_SWITCH_VOLT:
				return staticLoadSwitchVolt != STATIC_LOAD_SWITCH_VOLT_EDEFAULT;
			case DstabPackage.BASE_DSTAB_NETWORK__STATIC_LOAD_SWITCH_DEAD_ZONE:
				return staticLoadSwitchDeadZone != STATIC_LOAD_SWITCH_DEAD_ZONE_EDEFAULT;
			case DstabPackage.BASE_DSTAB_NETWORK__NET_EQN_ITERATION_NO_EVENT:
				return netEqnIterationNoEvent != NET_EQN_ITERATION_NO_EVENT_EDEFAULT;
			case DstabPackage.BASE_DSTAB_NETWORK__NET_EQN_ITERATION_WITH_EVENT:
				return netEqnIterationWithEvent != NET_EQN_ITERATION_WITH_EVENT_EDEFAULT;
			case DstabPackage.BASE_DSTAB_NETWORK__SATURATED_MACHINE_PARAMETER:
				return saturatedMachineParameter != SATURATED_MACHINE_PARAMETER_EDEFAULT;
			case DstabPackage.BASE_DSTAB_NETWORK__NET_CHANGE_LISTENER:
				return NET_CHANGE_LISTENER_EDEFAULT == null ? netChangeListener != null : !NET_CHANGE_LISTENER_EDEFAULT.equals(netChangeListener);
			case DstabPackage.BASE_DSTAB_NETWORK__DYNAMIC_EVENT_LIST:
				return dynamicEventList != null && !dynamicEventList.isEmpty();
			case DstabPackage.BASE_DSTAB_NETWORK__RELAY_MODEL_LIST:
				return relayModelList != null && !relayModelList.isEmpty();
			case DstabPackage.BASE_DSTAB_NETWORK__GEN_WITHOUT_BUS_LIST:
				return genWithoutBusList != null && !genWithoutBusList.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (dStabNetInitialized: ");
		result.append(dStabNetInitialized);
		result.append(", allowGenWithoutMach: ");
		result.append(allowGenWithoutMach);
		result.append(", yMatrix: ");
		result.append(yMatrix);
		result.append(", zeroSeqYMatrix: ");
		result.append(zeroSeqYMatrix);
		result.append(", negSeqYMatrix: ");
		result.append(negSeqYMatrix);
		result.append(", yMatrixDirty: ");
		result.append(yMatrixDirty);
		result.append(", staticLoadModel: ");
		result.append(staticLoadModel);
		result.append(", staticLoadSwitchVolt: ");
		result.append(staticLoadSwitchVolt);
		result.append(", staticLoadSwitchDeadZone: ");
		result.append(staticLoadSwitchDeadZone);
		result.append(", netEqnIterationNoEvent: ");
		result.append(netEqnIterationNoEvent);
		result.append(", netEqnIterationWithEvent: ");
		result.append(netEqnIterationWithEvent);
		result.append(", saturatedMachineParameter: ");
		result.append(saturatedMachineParameter);
		result.append(", netChangeListener: ");
		result.append(netChangeListener);
		result.append(')');
		return result.toString();
	}
	
			

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	@Override
	public String net2String() {
		final StringBuffer result = new StringBuffer("\nDStabilityNetwork Info:\n");

		result.append(super.net2String());

		if (this.getDynamicEventList().size() > 0) {
			result.append("\n\nDynamic Event Info: \n");
			for( DynamicSimuEvent event : this.getDynamicEventList()) {
				result.append(event.toString());
				result.append("\n");
			}
		}
/*
		result.append("\n\nMachine Info: \n");
		
		for (Bus b : this.getBusList()) {
			DStabBus bus = (DStabBus)b;
			for (DynamicBusDevice device : bus.getDynamicBusDeviceList()) {
				if ((device).getDeviceType() == DynamicBusDeviceType.DYNAMIC_MACHINE) {
					Machine mach = (Machine)device;
					result.append(mach.toString()+"\n");
					result.append(mach.getMachData().toString());
					if (mach.hasExciter())
						result.append(mach.getExciter().toString());
					if (mach.hasGovernor())
						result.append(mach.getGovernor().toString());
					if (mach.hasStabilizer())
						result.append(mach.getStabilizer().toString());
				}
				else if ((device).getDeviceType() == DynamicBusDeviceType.SCRIPT_DYNAMIC_BUS_DEVICE) {
						ScriptDynamicBusDevice sdevice = (ScriptDynamicBusDevice)device;
						result.append(sdevice.toString());
				}
				result.append("\n");
			}
		}		
*/		
		return result.toString();
	}

	@Override
	public void setAllowGenWithoutMach(boolean allowNoMach) {
		this.genWithoutMachAllowed = allowNoMach;
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ISparseEqnComplex getYMatrix() {
		return yMatrix;
	}

	@Override
	public boolean isAllowGenWithoutMach() {
		return this.genWithoutMachAllowed;
	}

	@Override
	public boolean hasGenWithoutMach() {
	
		return this.hasGenWithoutMach;
	}

	@Override
	public List<BaseDStabBus<DStabGen, DStabLoad>> getGenWithoutMachBusList() {
		
		return this.genWithoutMachBusList;
	}

	

	@Override
	public void setCustom3SeqBusCurrInjHashtable(
			Hashtable<String, Complex3x1> custom3SeqBusCurTable) {
		this.custom3SeqBusCurTable = custom3SeqBusCurTable;
		
	}

	@Override
	public Hashtable<String, Complex3x1> getCustom3SeqBusCurrInjHashtable() {
		
		return this.custom3SeqBusCurTable;
	}

	@Override
	public String getMachineInitCondition() {
		StringBuffer sb = new StringBuffer();
		sb.append(" ----------------------------- MACHINE INITIAL CONDITIONS ----------------------------------\n");
		sb.append("    BusID    NAME       KV   GenId   GenP    GenQ     P.F.    VT    ANGLE    EFD      ID    IQ \n");
		for(BaseDStabBus<?,?> bus: this.getBusList()){
			if (bus.getGenCode()!=AclfGenCode.NON_GEN && bus.getContributeGenList() != null) {
                if(bus.getContributeGenList().size()>0){
                   for(AclfGen gen:bus.getContributeGenList()){
                          if(gen.isActive()){
                        	  DStabGen dGen = (DStabGen) gen;
                        	  if(dGen.getMach()!=null)
                        	  sb.append(Number2String.toFixLengthStr(8,bus.getId())+Number2String.toFixLengthStr(10, bus.getName().trim())+"  "+Number2String.toFixLengthStr(bus.getBaseVoltage()/1000,"###0.00")
                        	          +"  "+Number2String.toFixLengthStr(3,gen.getId())
                        			  +"  "+Number2String.toFixLengthStr(gen.getGen().getReal()*this.getBaseMva(), "###0.00")+"  "+Number2String.toFixLengthStr(gen.getGen().getImaginary()*this.getBaseMva(), "###0.00")
                        			  +"  "+Number2String.toFixLengthStr(gen.getGen().getReal()/gen.getGen().abs(),"0.0000")
                        			  +"  "+Number2String.toFixLengthStr(bus.getVoltageMag(),"0.000")+"  "+ Number2String.toFixLengthStr(Math.toDegrees(dGen.getMach().getAngle()),"##0.00")
                        			  +"  "+Number2String.toStr( dGen.getMach().getEfd(),"0.0000")
                        			  +"  "+Number2String.toStr(dGen.getMach().getIdq().d,"0.0000")+"  "+Number2String.toStr(dGen.getMach().getIdq().q,"0.0000")+"\n");
                        	  
                        	  
                          }
                   }
                }
			}
		}
		return sb.toString();
	}

	@Override
	public boolean isDStabNetInitialized() {
		
		return this.isInitialized;
	}

	@Override
	public void setDStabNetInitialized(boolean initStatus) {
		this.isInitialized = initStatus;
	}

	@Override
	public boolean isStaticLoadIncludedInYMatrix() {
		
		return this.isStaticLoadIncludedInYMatrix;
	}

	@Override
	public void setStaticLoadIncludedInYMatrix(boolean value) {
		this.isStaticLoadIncludedInYMatrix = value;
		
	}

	

    private boolean staticLoadZPartInYMatrix;

    @Override public boolean isStaticLoadZPartInYMatrix() {
        return staticLoadZPartInYMatrix;
    }

    @Override public void setStaticLoadZPartInYMatrix(boolean enabled) {
        if (isDStabNetInitialized() && enabled != staticLoadZPartInYMatrix)
            throw new IllegalStateException("Configure static-load matrix treatment before initialization");
        staticLoadZPartInYMatrix = enabled;
    }

    private com.interpss.dstab.ConstantCurrentLoadVoltageCurve constantCurrentLoadVoltageCurve =
            com.interpss.dstab.ConstantCurrentLoadVoltageCurve.SINE;

    @Override public com.interpss.dstab.ConstantCurrentLoadVoltageCurve getConstantCurrentLoadVoltageCurve() {
        return constantCurrentLoadVoltageCurve;
    }

    @Override public void setConstantCurrentLoadVoltageCurve(com.interpss.dstab.ConstantCurrentLoadVoltageCurve curve) {
        constantCurrentLoadVoltageCurve = java.util.Objects.requireNonNull(curve);
    }

} //DStabilityNetworkImpl
