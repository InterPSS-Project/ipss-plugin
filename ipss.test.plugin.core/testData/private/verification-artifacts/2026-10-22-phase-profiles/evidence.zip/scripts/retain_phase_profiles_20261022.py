from pathlib import Path
import json,hashlib,zipfile,subprocess,statistics
r=Path.cwd();store=Path('D:/CodexSimulationArtifacts/01a14be5-6472-71c0-8c29-7bdf3e27b2ce')
names=['network-anderson-deferred-profile-20261022','network-phase-timers-20261022',
       'network-phase-timers-v2-20261022','controller-phase-timers-20261022',
       'st4-output-iterations-audit-20261022','st4-output-inputs-audit-20261022']
cache={}
def sha(p):
    t=p.stat();key=(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
    if key not in cache:
        with p.open('rb') as f:cache[key]=hashlib.file_digest(f,'sha256').hexdigest()
    return cache[key]
reference=store/'network-anderson-deferred-screen-20261022/case1/actual/case1_bus_fault_01/run-1'
hashes={n:sha(reference/n) for n in ('full-network.bin','interpss.csv','full-network-channels.json')}
deps=[];verified=0;counts={}
for name in names:
    root=store/name;runs=list((root/'actual/case1_bus_fault_01').glob('run-*'));counts[name]=len(runs)
    for run in runs:
        status=json.loads((run/'status.json').read_text());assert status['status']=='completed'
        for n,value in hashes.items():
            p=run/n;assert sha(p)==value,(name,run.name,n)
            deps.append(dict(storage='external-generated-artifacts',path=p.relative_to(store).as_posix(),sha256=value,bytes=p.stat().st_size))
        verified+=1
    if runs:
        affinity=json.loads((root/'affinity.json').read_text());assert affinity['observed_mask_before']==affinity['observed_mask_after']==1
assert list(counts.values())==[16,0,10,10,1,1]
profile=json.loads((store/names[0]/'profile-summary.json').read_text());profile.pop('top_stacks')
profile['verified_complete_recordings']=16
summaries={name:json.loads((store/name/'summary.json').read_text()) for name in names[2:]}
phase=summaries['controller-phase-timers-20261022']['measured'];medians={}
for category in ('phases','controllers'):
    medians[category]={k:statistics.median(x[category][k] for x in phase) for k in phase[0][category] if k.endswith('_s')}
archive=r/'ipss.test.plugin.core/testData/private/verification-artifacts/2026-10-22-phase-profiles/evidence.zip'
archive.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('private-storage-location.json',json.dumps({'external-generated-artifacts':str(store)},indent=2))
    z.writestr('retained-dependencies.json',json.dumps(deps,indent=2))
    z.writestr('verification.json',json.dumps(dict(completed_runs=verified,per_root=counts,hashes=hashes,affinity_mask=1),indent=2))
    z.writestr('attempt-classification.json',json.dumps({'network-phase-timers-20261022':'Harness compile failure: incorrect variable name; no simulation.','other_roots':'Completed audits; all recordings verified.'},indent=2))
    for name in names:
        for p in (store/name).rglob('*'):
            if p.is_file() and p.suffix in ('.json','.java','.class','.log','.txt','.jfr'):
                z.write(p,name+'/'+p.relative_to(store/name).as_posix())
        for p in store.glob(name+'.log*'):z.write(p,'logs/'+p.name)
    for name in ('profile_network_deferred','profile_network_history','time_network_phases','time_controller_phases',
                 'audit_st4_output_iterations','audit_st4_output_inputs','retain_phase_profiles'):
        p=r/'target'/(name+'_20261022.py');z.write(p,'scripts/'+p.name)
index=dict(schema=1,base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    description='Case 1 sampling profile, network/device wall-clock phase audits, and ST4B repeated-output input audit. No production optimization or new timing qualification.',
    prior_evidence=['network-deferred-screen-2026-10-22.json','dynamic-parameter-validation-extension-2026-10-22.json'],
    archive=archive.relative_to(r).as_posix(),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,
    verified_complete_recordings=verified,profile=profile,instrumented_phase_medians=medians,
    summaries=summaries,production_changed=False,retained_dependencies=deps)
(r/'docs/benchmarks/checkpoints/phase-profiles-2026-10-22.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps(dict(archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),verified_runs=verified,phase_medians=medians),indent=2))
