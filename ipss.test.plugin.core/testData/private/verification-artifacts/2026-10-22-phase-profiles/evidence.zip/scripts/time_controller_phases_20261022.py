from pathlib import Path
s=Path('target/time_network_phases_20261022.py').read_text()
s=s.replace("root=store/'network-phase-timers-v2-20261022'", "root=store/'controller-phase-timers-20261022'")
a=s.index("p=r/'target/fast-source");b=s.index("h=(parent/",a)
s=s[:a]+'''
cp=str(store/'network-phase-timers-v2-20261022/classes')+';'+cp
rel='ipss.plugin.core/src/main/java/org/interpss/dstab/algo/PsseStaggeredEulerSolver.java'
code=subprocess.check_output(['git','show','HEAD:'+rel],text=True)
a=code.index('    private void evaluate(boolean initialEndpoint, boolean prepareElectrical)')
b=code.index('    @Override public void nextStep',a)
part=code[a:b]
part=part.replace('        for (var p:gridForming)','        long section=System.nanoTime();\\n        for (var p:gridForming)',1)
part=part.replace('        for (int i=0;i<machines.size();i++)', '        phaseRenewable+=System.nanoTime()-section;\\n        for (int i=0;i<machines.size();i++)',1)
part=part.replace('            if(prepareElectrical && extendedStack', '            section=System.nanoTime();\\n            if(prepareElectrical && extendedStack',1)
part=part.replace('                electricalEndpointPreparationCount++;','                electricalEndpointPreparationCount++;phaseElectricalOnly+=System.nanoTime()-section;',1)
part=part.replace('            if (m.hasExciter()', '            phaseStabilizer+=System.nanoTime()-section;section=System.nanoTime();\\n            if (m.hasExciter()',1)
part=part.replace('            if (m.hasGovernor()', '            phaseExciter+=System.nanoTime()-section;section=System.nanoTime();\\n            if (m.hasGovernor()',1)
part=part.replace('            // Classical machines', '            phaseGovernor+=System.nanoTime()-section;section=System.nanoTime();\\n            // Classical machines',1)
needle='                throw new DStabSimuException("Machine derivative failed: "+m.getId());'
assert needle in part;part=part.replace(needle,needle+'\\n            phaseMachine+=System.nanoTime()-section;phaseMachineCalls++;')
code=code[:a]+part+code[b:]
needle='        for (var controller:localSt1Controllers) controller.advance(dt,discontinuity);'
assert needle in code
code=code.replace(needle,'        long localStarted=System.nanoTime();\\n'+needle+'\\n        phaseLocalSt1+=System.nanoTime()-localStarted;')
extra="""
    private long phaseRenewable,phaseStabilizer,phaseExciter,phaseGovernor,phaseMachine,
        phaseElectricalOnly,phaseLocalSt1,phaseMachineCalls;
    public Object getControllerPhaseAudit(){return java.util.Map.of("machine_evaluations",phaseMachineCalls,
        "renewable_evaluation_s",phaseRenewable/1.e9,"stabilizer_s",phaseStabilizer/1.e9,
        "exciter_s",phaseExciter/1.e9,"governor_s",phaseGovernor/1.e9,"machine_s",phaseMachine/1.e9,
        "electrical_only_s",phaseElectricalOnly/1.e9,"local_st1_advance_s",phaseLocalSt1/1.e9);}
"""
code=code[:code.rfind('}')]+extra+code[code.rfind('}'):]
source=root/'PsseStaggeredEulerSolver.java';source.write_text(code)
subprocess.run(['javac','-J-Xmx512m','-proc:none','-g','-cp',cp,'-d',str(root/'classes'),str(source)],check=True)
cp=str(root/'classes')+';'+cp
'''+s[b:]
s=s.replace('NetworkPhaseTimerRun','ControllerPhaseTimerRun')
s=s.replace("source=root/'ControllerPhaseTimerRun.java';source.write_text(h)", '''h=h.replace('            status.put("st1_boundary_reuses",boundaryReuses);','            status.put("st1_boundary_reuses",boundaryReuses);\\n            status.put("controller_phases",((PsseStaggeredEulerSolver)algo.getSolver()).getControllerPhaseAudit());')
source=root/'ControllerPhaseTimerRun.java';source.write_text(h)''')
s=s.replace("phases=x['status']['network_phases']", "phases=x['status']['network_phases'],controllers=x['status']['controller_phases']")
exec(compile(s,'controller-phase-timer-generator','exec'))
