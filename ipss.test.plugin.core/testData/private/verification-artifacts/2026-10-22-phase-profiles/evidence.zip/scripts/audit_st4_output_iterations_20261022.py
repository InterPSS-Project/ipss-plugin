from pathlib import Path
import json,subprocess,shutil,sys,hashlib
r=Path.cwd();store=Path('D:/CodexSimulationArtifacts/01a14be5-6472-71c0-8c29-7bdf3e27b2ce')
parent=store/'network-anderson-deferred-screen-20261022';root=store/'st4-output-iterations-audit-20261022';root.mkdir(exist_ok=False)
cmd=json.loads((parent/'case1/command.json').read_text());cp=cmd[cmd.index('-cp')+1]
cp=str(r/'target/parameter-validation-extension-20261022/classes')+';'+cp
rel='ipss.plugin.core/src/main/java/org/interpss/dstab/control/exc/ieee/y2005/st4b/St4DirectEvaluation.java'
s=subprocess.check_output(['git','show','HEAD:'+rel],text=True)
s=s.replace('    boolean refreshing;', '''    boolean refreshing;
    static long stepCalls,outputCalls,prepareCalls,voltageReads;
    static final long[] outputIterations=new long[65];
    public static Object auditCounts(){return java.util.Map.of("step_calls",stepCalls,"output_calls",outputCalls,
        "prepare_calls",prepareCalls,"voltage_reads",voltageReads,"output_iteration_histogram",outputIterations);}
''')
s=s.replace('        case 0: {','        case 0: {\n            voltageReads++;',1)
s=s.replace('    boolean step(boolean predictor,double dt) {','    boolean step(boolean predictor,double dt) {\n        stepCalls++;',1)
s=s.replace('    void prepare(boolean predictor,boolean capture) {','    void prepare(boolean predictor,boolean capture) {\n        prepareCalls++;',1)
s=s.replace('    double output() {','    double output() {\n        outputCalls++;',1)
s=s.replace('{converged=true;break;}','{converged=true;outputIterations[i+1]++;break;}',1)
source=root/'St4DirectEvaluation.java';source.write_text(s)
subprocess.run(['javac','-J-Xmx512m','-proc:none','-g','-cp',cp,'-d',str(root/'classes'),str(source)],check=True)
cp=str(root/'classes')+';'+cp
h=(parent/'NetworkAndersonDeferredScreenRun.java').read_text().replace('NetworkAndersonDeferredScreenRun','St4OutputAuditRun').replace('runIndex<22','runIndex<1')
h=h.replace('System.setProperty("ipss.experiment.networkAnderson",Boolean.toString(candidate));','System.setProperty("ipss.experiment.networkAnderson","true");')
h=h.replace('            status.put("st1_boundary_reuses",boundaryReuses);','''            status.put("st1_boundary_reuses",boundaryReuses);
            var counters=Class.forName("org.interpss.dstab.control.exc.ieee.y2005.st4b.St4DirectEvaluation").getDeclaredMethod("auditCounts");
            counters.setAccessible(true);status.put("st4_audit",counters.invoke(null));''')
source=root/'St4OutputAuditRun.java';source.write_text(h)
subprocess.run(['javac','-J-Xmx512m','-proc:none','-cp',cp,'-d',str(root/'harness'),str(source)],check=True)
shutil.copytree(parent/'case1/inputs',root/'inputs');shutil.copy2(parent/'case1/plan.json',root/'plan.json')
cmd[cmd.index('-cp')+1]=str(root/'harness')+';'+cp;cmd[-3]='org.interpss.core.dstab.reference.St4OutputAuditRun';cmd[-2]=str(root/'plan.json')
(root/'command.json').write_text(json.dumps(cmd,indent=2));sys.path.insert(0,str(r/'tools'));from replay_case2_fast_checkpoint import run_single_cpu
run_single_cpu(cmd,r,root)
expected=parent/'case1/actual/case1_bus_fault_01/run-1';actual=root/'actual/case1_bus_fault_01/run-0'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
hashes={n:digest(expected/n) for n in ('full-network.bin','interpss.csv','full-network-channels.json')}
for n,v in hashes.items():assert digest(actual/n)==v
status=json.loads((actual/'status.json').read_text());assert status['status']=='completed'
result=dict(audit=status['st4_audit'],all_recordings_identical=True,hashes=hashes)
(root/'summary.json').write_text(json.dumps(result,indent=2));print(result)
