from pathlib import Path
import json,subprocess,shutil,sys,hashlib
r=Path.cwd();store=Path('D:/CodexSimulationArtifacts/01a14be5-6472-71c0-8c29-7bdf3e27b2ce')
parent=store/'network-anderson-deferred-screen-20261022';root=store/'network-phase-timers-v2-20261022';root.mkdir(exist_ok=False)
cmd=json.loads((parent/'case1/command.json').read_text());cp=cmd[cmd.index('-cp')+1]
cp=str(r/'target/parameter-validation-extension-20261022/classes')+';'+cp
p=r/'target/fast-source-reconstruction-20261021/core-src/com/interpss/dstab/impl/BaseDStabNetworkImpl.java'
s=p.read_text();a=s.index('\tprivate boolean solveNetEqn_impl()');b=s.index('\n\t/**',a)
part=s[a:b]
part=part.replace('BaseDStabBus<?,?>[] runtimeBuses=dynamicRuntimeBuses();','long phase=System.nanoTime();\n        BaseDStabBus<?,?>[] runtimeBuses=dynamicRuntimeBuses();',1)
part=part.replace('boolean primitiveAssembly=primitiveCurrentAssemblyEligible();','phaseSetup+=System.nanoTime()-phase;phase=System.nanoTime();\n                boolean primitiveAssembly=primitiveCurrentAssemblyEligible();',1)
part=part.replace('addCustomBusCurrentInj();','phaseAssembly+=System.nanoTime()-phase;phase=System.nanoTime();\n                addCustomBusCurrentInj();\n                phaseCustom+=System.nanoTime()-phase;phase=System.nanoTime();',1)
part=part.replace('// update bus voltage and machine Pe','phaseSolve+=System.nanoTime()-phase;phase=System.nanoTime();\n                // update bus voltage and machine Pe',1)
part=part.replace('return true;','phasePublish+=System.nanoTime()-phase;phaseCalls++;\n        return true;',1)
s=s[:a]+'''    private long phaseSetup,phaseAssembly,phaseCustom,phaseSolve,phasePublish,phaseCalls;
    public Object getNetworkPhaseAudit(){return java.util.Map.of("calls",phaseCalls,
        "setup_s",phaseSetup/1.e9,"assembly_s",phaseAssembly/1.e9,"custom_s",phaseCustom/1.e9,
        "solve_s",phaseSolve/1.e9,"publish_s",phasePublish/1.e9);}
'''+part+s[b:]
source=root/'BaseDStabNetworkImpl.java';source.write_text(s)
subprocess.run(['javac','-J-Xmx512m','-proc:none','-g','-cp',cp,'-d',str(root/'classes'),str(source)],check=True)
cp=str(root/'classes')+';'+cp
h=(parent/'NetworkAndersonDeferredScreenRun.java').read_text().replace('NetworkAndersonDeferredScreenRun','NetworkPhaseTimerRun').replace('runIndex<22','runIndex<10').replace('runIndex<12','runIndex<8')
a=h.index('            boolean candidate=');b=h.index('            System.setProperty',a);h=h[:a]+'            boolean candidate=true;\n'+h[b:]
h=h.replace('            status.put("st1_boundary_reuses",boundaryReuses);','            status.put("st1_boundary_reuses",boundaryReuses);\n            status.put("network_phases",((com.interpss.dstab.impl.BaseDStabNetworkImpl<?,?>)net).getNetworkPhaseAudit());')
source=root/'NetworkPhaseTimerRun.java';source.write_text(h)
subprocess.run(['javac','-J-Xmx512m','-proc:none','-cp',cp,'-d',str(root/'harness'),str(source)],check=True)
shutil.copytree(parent/'case1/inputs',root/'inputs');shutil.copy2(parent/'case1/plan.json',root/'plan.json')
cmd[cmd.index('-cp')+1]=str(root/'harness')+';'+cp;cmd[-3]='org.interpss.core.dstab.reference.NetworkPhaseTimerRun';cmd[-2]=str(root/'plan.json')
(root/'command.json').write_text(json.dumps(cmd,indent=2));sys.path.insert(0,str(r/'tools'));from replay_case2_fast_checkpoint import run_single_cpu
run_single_cpu(cmd,r,root)
expected=parent/'case1/actual/case1_bus_fault_01/run-1';cache={}
def digest(p):
    t=p.stat();key=(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
    if key not in cache:
        with p.open('rb') as f:cache[key]=hashlib.file_digest(f,'sha256').hexdigest()
    return cache[key]
hashes={n:digest(expected/n) for n in ('full-network.bin','interpss.csv','full-network-channels.json')}
statuses=json.loads((root/'warm-statuses.json').read_text());assert len(statuses)==10
for run in statuses:
    for n,v in hashes.items():assert digest(root/f"actual/case1_bus_fault_01/run-{run['run']}"/n)==v
result=dict(completed_runs=10,all_recordings_identical=True,hashes=hashes,
    measured=[dict(total_s=x['complete_case_wall_s'],simulation_s=x['status']['simulation_output_wall_s'],phases=x['status']['network_phases']) for x in statuses if not x['warmup']],
    interpretation='Instrumented wall-clock phase totals; includes timer overhead and is not a performance qualification.')
(root/'summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
