from pathlib import Path
s=Path('target/audit_st4_output_iterations_20261022.py').read_text()
s=s.replace("root=store/'st4-output-iterations-audit-20261022'", "root=store/'st4-output-inputs-audit-20261022'")
needle="source=root/'St4DirectEvaluation.java';source.write_text(s)"
extra='''
s=s.replace('    static long stepCalls,outputCalls,prepareCalls,voltageReads;',"""    static long stepCalls,outputCalls,prepareCalls,voltageReads;
    static final long[] stepRefreshMasks=new long[64],firstOutputMasks=new long[64],secondOutputMasks=new long[64];
    private final long[] auditInputs=new long[6];
    private void auditReadInputs(){for(int i=0;i<6;i++)auditInputs[i]=Double.doubleToRawLongBits(nodes[i].block.getU());}
    private int auditInputMask(){int mask=0;for(int i=0;i<6;i++)if(auditInputs[i]!=Double.doubleToRawLongBits(nodes[i].block.getU()))mask|=1<<i;return mask;}
""")
s=s.replace('"prepare_calls",prepareCalls,"voltage_reads",voltageReads,"output_iteration_histogram",outputIterations',
    '"prepare_calls",prepareCalls,"voltage_reads",voltageReads,"output_iteration_histogram",outputIterations,"step_last_refresh_input_masks",stepRefreshMasks,"first_output_refresh_input_masks",firstOutputMasks,"second_output_refresh_input_masks",secondOutputMasks')
s=s.replace('prepare(predictor,false);prepare(predictor,false);return true;',
    'prepare(predictor,false);auditReadInputs();prepare(predictor,false);stepRefreshMasks[auditInputMask()]++;return true;')
s=s.replace('prepare(false,false);double value=0.+y(5);',
    'auditReadInputs();prepare(false,false);if(i==0)firstOutputMasks[auditInputMask()]++;if(i==1)secondOutputMasks[auditInputMask()]++;double value=0.+y(5);')
'''
assert needle in s;s=s.replace(needle,extra+'\n'+needle)
exec(compile(s,'st4-output-input-audit-generator','exec'))
