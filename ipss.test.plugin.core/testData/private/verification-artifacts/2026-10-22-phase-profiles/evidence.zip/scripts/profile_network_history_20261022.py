from pathlib import Path
from collections import Counter
import json,subprocess,shutil,sys,hashlib
r=Path.cwd();store=Path('D:/CodexSimulationArtifacts/01a14be5-6472-71c0-8c29-7bdf3e27b2ce');screen=store/'network-anderson-history-screen-20261022'
root=store/'network-anderson-history-profile-20261022';root.mkdir(exist_ok=False)
cmd=json.loads((screen/'case1/command.json').read_text(encoding='utf-8'));cp=cmd[cmd.index('-cp')+1]
h=(screen/'NetworkAndersonHistoryScreenRun.java').read_text(encoding='utf-8').replace('NetworkAndersonHistoryScreenRun','NetworkAndersonHistoryProfileRun').replace('runIndex<22','runIndex<10').replace('runIndex<12','runIndex<8')
a=h.index('            boolean candidate=');b=h.index('            System.setProperty',a);h=h[:a]+'            boolean candidate=true;\n'+h[b:]
needle='        var runs=new java.util.ArrayList<Map<String,Object>>();'
h=h.replace(needle,needle+'''
        var recording=new jdk.jfr.Recording();
        recording.enable("jdk.ExecutionSample").withPeriod(java.time.Duration.ofMillis(5)).withStackTrace();
        recording.setMaxSize(16L*1024*1024);
''',1)
needle='            long cpuBefore='
h=h.replace(needle,'            if(runIndex==8)recording.start();\n'+needle,1)
needle='    private static void runCase(String[] args) throws Exception {'
i=h.index(needle);prefix=h[:i];j=prefix.rfind('    }')
prefix=prefix[:j]+'''        recording.stop();recording.dump(root.resolve("profile.jfr"));recording.close();
'''+prefix[j:];h=prefix+h[i:]
source=root/'NetworkAndersonHistoryProfileRun.java';source.write_text(h,encoding='utf-8')
subprocess.run(['javac','-J-Xmx512m','-proc:none','-cp',cp,'-d',str(root/'classes'),str(source)],check=True)
shutil.copytree(screen/'case1/inputs',root/'inputs');shutil.copy2(screen/'case1/plan.json',root/'plan.json')
cmd[cmd.index('-cp')+1]=str(root/'classes')+';'+cp;cmd[-3]='org.interpss.core.dstab.reference.NetworkAndersonHistoryProfileRun';cmd[-2]=str(root/'plan.json')
(root/'command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8')
sys.path.insert(0,str(r/'tools'));from replay_case2_fast_checkpoint import run_single_cpu
run_single_cpu(cmd,r,root)
expected=screen/'case1/actual/case1_bus_fault_01/run-1';actual=root/'actual/case1_bus_fault_01/run-0'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name in ('full-network.bin','interpss.csv','full-network-channels.json'):assert digest(actual/name)==digest(expected/name)
p=subprocess.Popen(['jfr','print','--json','--stack-depth','64','--events','jdk.ExecutionSample',str(root/'profile.jfr')],stdout=subprocess.PIPE)
data=bytearray()
while b:=p.stdout.read(65536):
    data.extend(b)
    if len(data)>128*1024**2:p.kill();p.wait();raise RuntimeError('JFR JSON budget exceeded')
assert p.wait()==0
categories=Counter();leaves=Counter();main=0
for event in json.loads(data)['recording']['events']:
    v=event['values']
    if v.get('sampledThread',{}).get('javaName')!='main':continue
    frames=v.get('stackTrace',{}).get('frames',[])
    names=[f['method']['type']['name'].replace('/','.')+'.'+f['method']['name'] for f in frames]
    if not any(n.endswith('NetworkAndersonHistoryProfileRun.runCase') for n in names):continue
    main+=1;leaves[names[0]]+=1
    kind='other'
    if any('AndersonOne.' in n for n in names):kind='acceleration_history'
    elif any('.networkSolutionStep' in n or '.solveNetEqn' in n for n in names):kind='other_network'
    elif any('St1DirectEvaluation' in n for n in names):kind='ST1'
    elif any('Pss2' in n or 'pss2a.' in n for n in names):kind='PSS2A'
    elif any('FullNetwork' in n or 'SelectedRecorder' in n for n in names):kind='recording'
    categories[kind]+=1
result=dict(samples=main,categories=dict(categories),top_leaves=leaves.most_common(30),warmups=8,profiled_runs=2,sample_period_ms=5,recordings_match=True,interpretation='Main-thread samples with runCase on stack; approximate attribution, not exclusive wall-clock timers. Compilation/GC remain in runs.')
(root/'profile-summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(result,flush=True)
