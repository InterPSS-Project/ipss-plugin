package org.interpss.dstab.control.exc.ieee.y2005.st4b;

import java.util.*;
import com.interpss.dstab.controller.cml.ICMLMachineVoltageProvider;
import com.interpss.dstab.controller.cml.field.*;
import com.interpss.dstab.controller.cml.field.adapt.CMLControlBlockAdapter;
import com.interpss.dstab.controller.cml.field.block.DelayControlBlock;
import com.interpss.dstab.controller.cml.field.func.LowValueFunction;
import com.interpss.dstab.controller.cml.runtime.CmlBlockKernel;
import com.interpss.dstab.controller.cml.wrapper.*;

/** Experimental standard ST4 graph preserving state kernels and all refresh passes. */
final class St4DirectEvaluation {
    final IEEE2005ST4BExciter model;
    final Node[] nodes=new Node[6];
    final Node[] ordered;
    final double[] inputs=new double[6],states=new double[6],rates=new double[6];
    boolean refreshing;
    static long stepCalls,outputCalls,prepareCalls,voltageReads;
    static final long[] outputIterations=new long[65];
    public static Object auditCounts(){return java.util.Map.of("step_calls",stepCalls,"output_calls",outputCalls,
        "prepare_calls",prepareCalls,"voltage_reads",voltageReads,"output_iteration_histogram",outputIterations);}

    St4DirectEvaluation(IEEE2005ST4BExciter model) {
        this.model=model;var order=new ArrayList<Node>();boolean gateFound=false;
        for(var wrapper:model.getFieldWrapperList()) {
            if(wrapper.getFieldName().equals("voelGate")) {
                if(wrapper.getField().getClass()!=LowValueFunction.class)throw new IllegalStateException("Custom gate");
                gateFound=true;continue;
            }
            int id=switch(wrapper.getFieldName()) {
                case "trDelayBlock"->0;case "vrPIBlock"->1;case "taDelayBlock"->2;
                case "kgGainBlock"->3;case "vmPIBlock"->4;case "customBlock"->5;
                default->throw new IllegalStateException("Unexpected ST4 field");
            };
            Node node=new Node(id,(BlockFieldAnWrapper<?>)wrapper);nodes[id]=node;order.add(node);
        }
        if(!gateFound)throw new IllegalStateException("Missing gate");
        for(Node node:nodes)Objects.requireNonNull(node);
        order.sort(Comparator.comparingInt(n->n.wrapper.getInitOrder()));ordered=order.toArray(Node[]::new);
    }
    double y(int id) {return nodes[id].block.getY();}
    double input(int id) {
        switch(id) {
        case 0: {
            voltageReads++;
            var machine=model.getMachine();
            return 0.+(machine instanceof ICMLMachineVoltageProvider p?p.getCmlMachineVoltage()
                :model.getDStabBus().getVoltage().abs()/machine.getVMultiFactor());
        }
        case 1: {
            double a=model.getRefPoint(),b=y(0);
            var machine=model.getMachine();
            double c=machine.getStabilizer()==null?0.:machine.getStabilizer().getOutput(machine),d=model.vuel;
            double sum=0.;sum+=a;sum+=-b;sum+=c;sum+=d;return sum;
        }
        case 2:return 0.+y(1);
        case 3:return 0.+y(5);
        case 4: {double a=y(2),b=y(3);double sum=0.;sum+=a;sum+=-b;return sum;}
        case 5: {
            double a=y(4),b=y(4),c=y(4),d=model.voel;
            double gate=c<d?c:d;
            double sum=0.;sum+=a;sum+=-b;sum+=gate;return sum;
        }
        default:throw new IllegalArgumentException();
        }
    }
    boolean step(boolean predictor,double dt) {
        stepCalls++;
        prepare(predictor,true);
        for(Node node:ordered)if(node.control)node.kernel.advance(predictor,inputs[node.id],dt,null,null,states,rates,node.id);
        prepare(predictor,false);prepare(predictor,false);return true;
    }
    void prepare(boolean predictor,boolean capture) {
        prepareCalls++;
        for(Node node:ordered)node.prepare(predictor,capture);
        for(Node node:ordered)if(!node.control && node.wrapper.isFeedback())node.prepare(predictor,false);
    }
    boolean algebraic() {
        for(Node node:nodes)if(node.block instanceof DelayControlBlock d && d.getT()==0.)return true;
        return false;
    }
    double output() {
        outputCalls++;
        if(!refreshing && algebraic()) {
            refreshing=true;
            try {
                double previous=Double.NaN;boolean converged=false;
                for(int i=0;i<64;i++) {
                    prepare(false,false);double value=0.+y(5);
                    if(Double.isFinite(value)&&Math.abs(value-previous)<=1.e-14*(1.+Math.abs(value))) {converged=true;outputIterations[i+1]++;break;}
                    previous=value;
                }
                if(!converged)return Double.NaN;
            }finally {refreshing=false;}
        }
        return 0.+y(5);
    }
    final class Node {
        final int id;final BlockFieldAnWrapper<?> wrapper;final ICMLStaticBlock block;
        final CmlBlockKernel kernel;final boolean control;
        Node(int id,BlockFieldAnWrapper<?> wrapper) {
            this.id=id;this.wrapper=wrapper;block=(ICMLStaticBlock)wrapper.getField();
            control=wrapper instanceof ControlBlockFieldAnWrapper;kernel=CmlBlockKernel.create(block);
            if(block instanceof ICMLLimitBlock limited && limited.getLimit()!=null &&
                (limited.getLimit().getMaxExp()!=null || limited.getLimit().getMinExp()!=null))
                throw new IllegalStateException("Variable limit requires general evaluator");
        }
        void prepare(boolean predictor,boolean capture) {
            if(wrapper.getField()!=block)throw new IllegalStateException("ST4 field replaced");
            double value=input(id);
            if(control) {((CMLControlBlockAdapter)block).setStageInput(value);if(capture)inputs[id]=value;}
            else if(predictor)block.eulerStep1(value,0.);else block.eulerStep2(value,0.);
        }
    }
}
