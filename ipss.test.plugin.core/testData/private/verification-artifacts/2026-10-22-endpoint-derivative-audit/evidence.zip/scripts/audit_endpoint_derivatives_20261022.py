from pathlib import Path
import json,subprocess,shutil,sys,hashlib
r=Path.cwd();store=Path('D:/CodexSimulationArtifacts/01a14be5-6472-71c0-8c29-7bdf3e27b2ce')
parent=store/'network-anderson-deferred-screen-20261022'
root=store/'endpoint-derivative-audit-20261022';root.mkdir(exist_ok=False)
cmd=json.loads((parent/'case1/command.json').read_text());cp=cmd[cmd.index('-cp')+1]
cp=str(r/'target/parameter-validation-extension-20261022/classes')+';'+cp
rel='ipss.plugin.core/src/main/java/org/interpss/dstab/algo/PsseStaggeredEulerSolver.java'
s=subprocess.check_output(['git','show','HEAD:'+rel],text=True)
s=s.replace('                machineActive.add(ownerActive);','                machineActive.add(ownerActive);\n                int auditFirstState=states.size();')
needle='                electricalEndpointEligible.add(endpointEligibility(m,exciter,governor,stabilizer));'
assert needle in s;s=s.replace(needle,needle+'\n                auditRanges.put(m,new int[]{auditFirstState,states.size()});',1)
needle='''        if (discontinuity) rebaseDynamicModelInputs(method);
        evaluate();'''
assert needle in s;s=s.replace(needle,'''        if (discontinuity) rebaseDynamicModelInputs(method);
        long[] endpointBefore=reuse?auditSnapshot():null;
        evaluate();
        if(endpointBefore!=null)auditCompare(endpointBefore,auditSnapshot(),time);''',1)
extra='''
    private record EndpointProbe(String machine,String name,DoubleSupplier value) { }
    private final java.util.IdentityHashMap<Machine,int[]> auditRanges=new java.util.IdentityHashMap<>();
    private final java.util.ArrayList<EndpointProbe> auditProbes=new java.util.ArrayList<>();
    private final java.util.Map<String,Long> auditChangedCalls=new java.util.TreeMap<>();
    private final java.util.Map<String,Long> auditChangedFields=new java.util.TreeMap<>();
    private final java.util.Map<String,Double> auditFirstChangedTime=new java.util.TreeMap<>();
    private final java.util.ArrayList<double[]> auditParticipantValues=new java.util.ArrayList<>();
    private long auditCalls,auditFullyUnchangedCalls;
    public Object getEndpointAudit() {
        return java.util.Map.of("calls",auditCalls,"fully_unchanged_calls",auditFullyUnchangedCalls,
            "probe_count",auditProbes.size(),"machine_changed_calls",auditChangedCalls,
            "field_changed_calls",auditChangedFields,"first_changed_time",auditFirstChangedTime);
    }
    private void auditProbe(String machine,String name,DoubleSupplier value) {
        auditProbes.add(new EndpointProbe(machine,name,value));
    }
    private void auditBlock(String machine,String name,Object field) {
        if(field instanceof AbstractAnnotateController c) {
            for(var w:c.getFieldWrapperList())auditBlock(machine,name+"."+w.getFieldName(),w.getField());
        } else if(field instanceof com.interpss.dstab.controller.cml.field.ICMLStaticBlock b) {
            auditProbe(machine,name+".u",b::getU);
            if(field instanceof com.interpss.dstab.controller.cml.field.adapt.CMLControlBlockAdapter c)
                auditProbe(machine,name+".x",c::getStateX);
            if(field instanceof CMLControlBlock1stOrderAdapter c)auditProbe(machine,name+".dx",c::getDX_dt);
            if(field instanceof Pss2aLeadLagBlock c)auditProbe(machine,name+".dx",c::getStateDerivative);
            if(field instanceof FilterNthOrderBlock c) {
                int i=0;for(var b2:c.getIntegrationBlocks())auditBlock(machine,name+"["+(i++)+"]",b2);
            }
        }
    }
    private void auditBind() {
        for(var m:machines) {
            String id=m.getId();int[] range=auditRanges.get(m);
            for(int i=range[0];i<range[1];i++) {
                State state=states.get(i);auditProbe(id,"state["+(i-range[0])+"].x",state.value);
                auditProbe(id,"state["+(i-range[0])+"].dx",state.derivative);
            }
            auditProbe(id,"Pe",m::getPe);auditProbe(id,"Pm",m::getPm);auditProbe(id,"Efd",m::getEfd);
            auditBlock(id,"exciter",m.getExciter());auditBlock(id,"stabilizer",m.getStabilizer());
            if(m.getGovernor() instanceof AbstractAnnotateController c && c.getFieldWrapperList()!=null)
                auditBlock(id,"governor",c);
        }
        for(var p:participants) {
            double[] values=new double[p.values.length];auditParticipantValues.add(values);
            String id="participant:"+p.model.getClass().getSimpleName()+":"+(auditParticipantValues.size()-1);
            for(int i=0;i<values.length;i++) {
                int slot=i;auditProbe(id,"x["+i+"]",()->values[slot]);
                auditProbe(id,"dx["+i+"]",()->p.rates[slot]);
            }
        }
    }
    private long[] auditSnapshot() {
        if(auditProbes.isEmpty())auditBind();
        for(int i=0;i<participants.size();i++)participants.get(i).model.readStaggeredState(auditParticipantValues.get(i),0);
        long[] values=new long[auditProbes.size()];
        for(int i=0;i<values.length;i++)values[i]=Double.doubleToRawLongBits(auditProbes.get(i).value.getAsDouble());
        return values;
    }
    private void auditCompare(long[] before,long[] after,double time) {
        auditCalls++;var changed=new java.util.HashSet<String>();
        for(int i=0;i<before.length;i++)if(before[i]!=after[i]) {
            var p=auditProbes.get(i);changed.add(p.machine);
            String key=p.machine+"/"+p.name;auditChangedFields.merge(key,1L,Long::sum);
            auditFirstChangedTime.putIfAbsent(key,time);
        }
        if(changed.isEmpty())auditFullyUnchangedCalls++;
        for(String machine:changed)auditChangedCalls.merge(machine,1L,Long::sum);
    }
'''
s=s[:s.rfind('}')]+extra+s[s.rfind('}'):]
source=root/'PsseStaggeredEulerSolver.java';source.write_text(s)
subprocess.run(['javac','-J-Xmx512m','-proc:none','-g','-cp',cp,'-d',str(root/'classes'),str(source)],check=True)
cp=str(root/'classes')+';'+cp
h=(parent/'NetworkAndersonDeferredScreenRun.java').read_text().replace('NetworkAndersonDeferredScreenRun','EndpointDerivativeAuditRun').replace('runIndex<22','runIndex<1')
h=h.replace('System.setProperty("ipss.experiment.networkAnderson",Boolean.toString(candidate));','System.setProperty("ipss.experiment.networkAnderson","true");')
h=h.replace('            status.put("st1_boundary_reuses",boundaryReuses);','            status.put("st1_boundary_reuses",boundaryReuses);\n            status.put("endpoint_audit",((PsseStaggeredEulerSolver)algo.getSolver()).getEndpointAudit());')
source=root/'EndpointDerivativeAuditRun.java';source.write_text(h)
subprocess.run(['javac','-J-Xmx512m','-proc:none','-cp',cp,'-d',str(root/'harness'),str(source)],check=True)
sys.path.insert(0,str(r/'tools'));from replay_case2_fast_checkpoint import run_single_cpu
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
results=[]
for case in (1,2):
    baseline=parent/f'case{case}';out=root/f'case{case}';out.mkdir()
    shutil.copytree(baseline/'inputs',out/'inputs');shutil.copy2(baseline/'plan.json',out/'plan.json')
    command=json.loads((baseline/'command.json').read_text());command[command.index('-cp')+1]=str(root/'harness')+';'+cp
    command[-3]='org.interpss.core.dstab.reference.EndpointDerivativeAuditRun';command[-2]=str(out/'plan.json')
    (out/'command.json').write_text(json.dumps(command,indent=2));run_single_cpu(command,r,out)
    actual=out/f'actual/case{case}_bus_fault_01/run-0';expected=baseline/f'actual/case{case}_bus_fault_01/run-1'
    status=json.loads((actual/'status.json').read_text());assert status['status']=='completed'
    hashes={n:digest(actual/n) for n in ('full-network.bin','interpss.csv','full-network-channels.json')}
    for name,value in hashes.items():assert value==digest(expected/name),(case,name)
    result=dict(case=case,audit=status['endpoint_audit'],all_recordings_identical=True,hashes=hashes)
    results.append(result);(root/'summary.json').write_text(json.dumps(results,indent=2))
    print({k:v for k,v in result.items() if k!='audit'}, {k:v for k,v in result['audit'].items() if k in ('calls','fully_unchanged_calls','probe_count')},flush=True)
