from pathlib import Path
s=Path('target/audit_endpoint_derivatives_20261022.py').read_text()
s=s.replace("root=store/'endpoint-derivative-audit-20261022'", "root=store/'endpoint-boundary-details-v2-20261022'")
s=s.replace('for case in (1,2):','for case in (2,):')
s=s.replace('    private long auditCalls,auditFullyUnchangedCalls;', '''    private long auditCalls,auditFullyUnchangedCalls;
    private final java.util.ArrayList<Object> auditDetails=new java.util.ArrayList<>();
    private double auditPreviousFrequency=Double.NaN;
''')
s=s.replace('"probe_count",auditProbes.size(),"machine_changed_calls",auditChangedCalls,', '"probe_count",auditProbes.size(),"details",auditDetails,"machine_changed_calls",auditChangedCalls,')
s=s.replace('String key=p.machine+"/"+p.name;auditChangedFields.merge(key,1L,Long::sum);', '''String key=p.machine+"/"+p.name;auditChangedFields.merge(key,1L,Long::sum);
            if(key.equals("Bus5263-mach1/exciter.washoutBlock.dx")
                    || key.equals("Bus1050-mach1/stabilizer.customBlock2.delayBlock.u") && auditDetails.size()<12) {
                Machine machine=dstabAlgo.getNetwork().getMachine(p.machine);
                auditDetails.add(java.util.Map.of("field",key,"time",time,
                    "before",Double.longBitsToDouble(before[i]),"after",Double.longBitsToDouble(after[i]),
                    "before_bits",Long.toHexString(before[i]),"after_bits",Long.toHexString(after[i]),
                    "bus_frequency",machine.getDStabBus().getFreq(),"previous_endpoint_frequency",Double.toString(auditPreviousFrequency),
                    "exciter",machine.getExciter().getClass().getSimpleName(),
                    "input2_selector",machine.getStabilizer() instanceof Ieee1992PSS2AStabilizer pss?pss.getData().getIcs2():-1));
            }
''')
# Record the frequency after the endpoint controller evaluation, before the bus
# frequency filter's accepted-step update. No numerical operation is omitted.
s=s.replace("s=s[:s.rfind('}')]+extra+s[s.rfind('}'):]", '''s=s[:s.rfind('}')]+extra+s[s.rfind('}'):]
needle="""        evaluate();
        for (var p:participants)
            if (p.active.getAsBoolean() && p.model instanceof IeeestStabilizer stabilizer)
                stabilizer.acceptVoltageDerivativeEndpoint(time+dt,dt);"""
assert needle in s
s=s.replace(needle,needle.replace('        evaluate();','        evaluate();\\n        auditPreviousFrequency=dstabAlgo.getNetwork().getMachine("Bus1050-mach1").getDStabBus().getFreq();'))
''')
exec(compile(s,'endpoint-boundary-details-generator','exec'))
