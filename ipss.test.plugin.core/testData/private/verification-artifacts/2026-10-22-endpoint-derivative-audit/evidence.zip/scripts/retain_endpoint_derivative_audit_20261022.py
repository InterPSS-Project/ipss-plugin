from pathlib import Path
import json,hashlib,zipfile,subprocess,collections
r=Path.cwd();store=Path('D:/CodexSimulationArtifacts/01a14be5-6472-71c0-8c29-7bdf3e27b2ce')
names=['endpoint-derivative-audit-20261022','endpoint-boundary-details-20261022','endpoint-boundary-details-v2-20261022']
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
deps=[]
for name in names:
    for p in (store/name).rglob('*'):
        if p.is_file() and p.name in ('full-network.bin','interpss.csv','full-network-channels.json'):
            deps.append(dict(storage='external-generated-artifacts',path=p.relative_to(store).as_posix(),sha256=sha(p),bytes=p.stat().st_size))
summaries=[]
for x in json.loads((store/names[0]/'summary.json').read_text()):
    a=x['audit'];fields=a['field_changed_calls'];machines=a['machine_changed_calls']
    aggregate=collections.Counter()
    for key,count in fields.items():
        if count>1:aggregate[key.split('/',1)[1]]+=1
    summaries.append(dict(case=x['case'],calls=a['calls'],probe_count=a['probe_count'],
        fully_unchanged_calls=a['fully_unchanged_calls'],
        machine_change_count_histogram=dict(collections.Counter(v for k,v in machines.items() if not k.startswith('participant:'))),
        participant_change_count_histogram=dict(collections.Counter(v for k,v in machines.items() if k.startswith('participant:'))),
        repeated_change_field_counts=dict(aggregate),first_change_time_histogram=dict(collections.Counter(a['first_changed_time'].values())),
        state_value_changes=sum(v for k,v in fields.items() if k.endswith('.x') or '/x[' in k),
        all_recordings_identical=x['all_recordings_identical'],hashes=x['hashes']))
details=json.loads((store/names[2]/'summary.json').read_text())[0]
zero_samples=[x for x in details['audit']['details'] if x['field'].startswith('Bus5263')]
assert len(zero_samples)==6 and all(x['before']==x['after']==0 for x in zero_samples)
archive=r/'ipss.test.plugin.core/testData/private/verification-artifacts/2026-10-22-endpoint-derivative-audit/evidence.zip'
archive.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('private-storage-location.json',json.dumps({'external-generated-artifacts':str(store)},indent=2))
    z.writestr('retained-dependencies.json',json.dumps(deps,indent=2))
    z.writestr('attempt-classification.json',json.dumps({names[0]:'completed Cases 1 and 2',names[1]:'audit serialization failure: initial missing frequency was a numeric NaN; not dynamic failure',names[2]:'completed Case 2; missing frequency represented as text'},indent=2))
    for name in names:
        for p in (store/name).rglob('*'):
            if p.is_file() and p.suffix in ('.json','.java','.class','.log','.txt'):
                z.write(p,name+'/'+p.relative_to(store/name).as_posix())
        for p in store.glob(name+'.log*'):z.write(p,'logs/'+p.name)
    for name in ('audit_endpoint_derivatives','audit_endpoint_boundary_details','retain_endpoint_derivative_audit'):
        p=r/'target'/(name+'_20261022.py');z.write(p,'scripts/'+p.name)
index=dict(schema=1,base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    description='Non-mutating audit of initial evaluation after a reusable network endpoint. No integration evaluations were skipped; no performance claim.',
    prior_evidence=['network-deferred-screen-2026-10-22.json','dynamic-parameter-validation-extension-2026-10-22.json'],
    archive=archive.relative_to(r).as_posix(),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,
    completed_runs=3,summaries=summaries,detail_samples=details['audit']['details'],
    coverage_limitations=['Renewable internal states are not audited.','Read-only stored state and derivative access; output getters intentionally excluded.','No general proof for arbitrary callbacks, parameter edits, activation changes or observers.'],
    production_changed=False,retained_dependencies=deps)
(r/'docs/benchmarks/checkpoints/endpoint-derivative-audit-2026-10-22.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'dependencies':len(deps),'summaries':summaries},indent=2))
